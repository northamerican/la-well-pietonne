var __create = Object.create;
var __defProp = Object.defineProperty;
var __defProps = Object.defineProperties;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropDescs = Object.getOwnPropertyDescriptors;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getOwnPropSymbols = Object.getOwnPropertySymbols;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __propIsEnum = Object.prototype.propertyIsEnumerable;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __spreadValues = (a, b) => {
  for (var prop in b || (b = {}))
    if (__hasOwnProp.call(b, prop))
      __defNormalProp(a, prop, b[prop]);
  if (__getOwnPropSymbols)
    for (var prop of __getOwnPropSymbols(b)) {
      if (__propIsEnum.call(b, prop))
        __defNormalProp(a, prop, b[prop]);
    }
  return a;
};
var __spreadProps = (a, b) => __defProps(a, __getOwnPropDescs(b));
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target, mod));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// node_modules/esbuild/lib/main.js
var require_main = __commonJS({
  "node_modules/esbuild/lib/main.js"(exports, module2) {
    "use strict";
    var __defProp2 = Object.defineProperty;
    var __getOwnPropDesc2 = Object.getOwnPropertyDescriptor;
    var __getOwnPropNames2 = Object.getOwnPropertyNames;
    var __hasOwnProp2 = Object.prototype.hasOwnProperty;
    var __export2 = (target, all) => {
      for (var name in all)
        __defProp2(target, name, { get: all[name], enumerable: true });
    };
    var __copyProps2 = (to, from, except, desc) => {
      if (from && typeof from === "object" || typeof from === "function") {
        for (let key of __getOwnPropNames2(from))
          if (!__hasOwnProp2.call(to, key) && key !== except)
            __defProp2(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc2(from, key)) || desc.enumerable });
      }
      return to;
    };
    var __toCommonJS2 = (mod) => __copyProps2(__defProp2({}, "__esModule", { value: true }), mod);
    var node_exports = {};
    __export2(node_exports, {
      analyzeMetafile: () => analyzeMetafile,
      analyzeMetafileSync: () => analyzeMetafileSync,
      build: () => build,
      buildSync: () => buildSync,
      default: () => node_default,
      formatMessages: () => formatMessages,
      formatMessagesSync: () => formatMessagesSync,
      initialize: () => initialize,
      serve: () => serve,
      transform: () => transform,
      transformSync: () => transformSync,
      version: () => version
    });
    module2.exports = __toCommonJS2(node_exports);
    function encodePacket(packet) {
      let visit = (value) => {
        if (value === null) {
          bb.write8(0);
        } else if (typeof value === "boolean") {
          bb.write8(1);
          bb.write8(+value);
        } else if (typeof value === "number") {
          bb.write8(2);
          bb.write32(value | 0);
        } else if (typeof value === "string") {
          bb.write8(3);
          bb.write(encodeUTF8(value));
        } else if (value instanceof Uint8Array) {
          bb.write8(4);
          bb.write(value);
        } else if (value instanceof Array) {
          bb.write8(5);
          bb.write32(value.length);
          for (let item of value) {
            visit(item);
          }
        } else {
          let keys = Object.keys(value);
          bb.write8(6);
          bb.write32(keys.length);
          for (let key of keys) {
            bb.write(encodeUTF8(key));
            visit(value[key]);
          }
        }
      };
      let bb = new ByteBuffer();
      bb.write32(0);
      bb.write32(packet.id << 1 | +!packet.isRequest);
      visit(packet.value);
      writeUInt32LE(bb.buf, bb.len - 4, 0);
      return bb.buf.subarray(0, bb.len);
    }
    function decodePacket(bytes) {
      let visit = () => {
        switch (bb.read8()) {
          case 0:
            return null;
          case 1:
            return !!bb.read8();
          case 2:
            return bb.read32();
          case 3:
            return decodeUTF8(bb.read());
          case 4:
            return bb.read();
          case 5: {
            let count = bb.read32();
            let value2 = [];
            for (let i = 0; i < count; i++) {
              value2.push(visit());
            }
            return value2;
          }
          case 6: {
            let count = bb.read32();
            let value2 = {};
            for (let i = 0; i < count; i++) {
              value2[decodeUTF8(bb.read())] = visit();
            }
            return value2;
          }
          default:
            throw new Error("Invalid packet");
        }
      };
      let bb = new ByteBuffer(bytes);
      let id = bb.read32();
      let isRequest = (id & 1) === 0;
      id >>>= 1;
      let value = visit();
      if (bb.ptr !== bytes.length) {
        throw new Error("Invalid packet");
      }
      return { id, isRequest, value };
    }
    var ByteBuffer = class {
      constructor(buf = new Uint8Array(1024)) {
        this.buf = buf;
        this.len = 0;
        this.ptr = 0;
      }
      _write(delta) {
        if (this.len + delta > this.buf.length) {
          let clone = new Uint8Array((this.len + delta) * 2);
          clone.set(this.buf);
          this.buf = clone;
        }
        this.len += delta;
        return this.len - delta;
      }
      write8(value) {
        let offset = this._write(1);
        this.buf[offset] = value;
      }
      write32(value) {
        let offset = this._write(4);
        writeUInt32LE(this.buf, value, offset);
      }
      write(bytes) {
        let offset = this._write(4 + bytes.length);
        writeUInt32LE(this.buf, bytes.length, offset);
        this.buf.set(bytes, offset + 4);
      }
      _read(delta) {
        if (this.ptr + delta > this.buf.length) {
          throw new Error("Invalid packet");
        }
        this.ptr += delta;
        return this.ptr - delta;
      }
      read8() {
        return this.buf[this._read(1)];
      }
      read32() {
        return readUInt32LE(this.buf, this._read(4));
      }
      read() {
        let length = this.read32();
        let bytes = new Uint8Array(length);
        let ptr = this._read(bytes.length);
        bytes.set(this.buf.subarray(ptr, ptr + length));
        return bytes;
      }
    };
    var encodeUTF8;
    var decodeUTF8;
    if (typeof TextEncoder !== "undefined" && typeof TextDecoder !== "undefined") {
      let encoder = new TextEncoder();
      let decoder = new TextDecoder();
      encodeUTF8 = (text) => encoder.encode(text);
      decodeUTF8 = (bytes) => decoder.decode(bytes);
    } else if (typeof Buffer !== "undefined") {
      encodeUTF8 = (text) => {
        let buffer = Buffer.from(text);
        if (!(buffer instanceof Uint8Array)) {
          buffer = new Uint8Array(buffer);
        }
        return buffer;
      };
      decodeUTF8 = (bytes) => {
        let { buffer, byteOffset, byteLength } = bytes;
        return Buffer.from(buffer, byteOffset, byteLength).toString();
      };
    } else {
      throw new Error("No UTF-8 codec found");
    }
    function readUInt32LE(buffer, offset) {
      return buffer[offset++] | buffer[offset++] << 8 | buffer[offset++] << 16 | buffer[offset++] << 24;
    }
    function writeUInt32LE(buffer, value, offset) {
      buffer[offset++] = value;
      buffer[offset++] = value >> 8;
      buffer[offset++] = value >> 16;
      buffer[offset++] = value >> 24;
    }
    var buildLogLevelDefault = "warning";
    var transformLogLevelDefault = "silent";
    function validateTarget(target) {
      target += "";
      if (target.indexOf(",") >= 0)
        throw new Error(`Invalid target: ${target}`);
      return target;
    }
    var canBeAnything = () => null;
    var mustBeBoolean = (value) => typeof value === "boolean" ? null : "a boolean";
    var mustBeBooleanOrObject = (value) => typeof value === "boolean" || typeof value === "object" && !Array.isArray(value) ? null : "a boolean or an object";
    var mustBeString = (value) => typeof value === "string" ? null : "a string";
    var mustBeRegExp = (value) => value instanceof RegExp ? null : "a RegExp object";
    var mustBeInteger = (value) => typeof value === "number" && value === (value | 0) ? null : "an integer";
    var mustBeFunction = (value) => typeof value === "function" ? null : "a function";
    var mustBeArray = (value) => Array.isArray(value) ? null : "an array";
    var mustBeObject = (value) => typeof value === "object" && value !== null && !Array.isArray(value) ? null : "an object";
    var mustBeWebAssemblyModule = (value) => value instanceof WebAssembly.Module ? null : "a WebAssembly.Module";
    var mustBeArrayOrRecord = (value) => typeof value === "object" && value !== null ? null : "an array or an object";
    var mustBeObjectOrNull = (value) => typeof value === "object" && !Array.isArray(value) ? null : "an object or null";
    var mustBeStringOrBoolean = (value) => typeof value === "string" || typeof value === "boolean" ? null : "a string or a boolean";
    var mustBeStringOrObject = (value) => typeof value === "string" || typeof value === "object" && value !== null && !Array.isArray(value) ? null : "a string or an object";
    var mustBeStringOrArray = (value) => typeof value === "string" || Array.isArray(value) ? null : "a string or an array";
    var mustBeStringOrUint8Array = (value) => typeof value === "string" || value instanceof Uint8Array ? null : "a string or a Uint8Array";
    var mustBeStringOrURL = (value) => typeof value === "string" || value instanceof URL ? null : "a string or a URL";
    function getFlag(object, keys, key, mustBeFn) {
      let value = object[key];
      keys[key + ""] = true;
      if (value === void 0)
        return void 0;
      let mustBe = mustBeFn(value);
      if (mustBe !== null)
        throw new Error(`"${key}" must be ${mustBe}`);
      return value;
    }
    function checkForInvalidFlags(object, keys, where) {
      for (let key in object) {
        if (!(key in keys)) {
          throw new Error(`Invalid option ${where}: "${key}"`);
        }
      }
    }
    function validateInitializeOptions(options) {
      let keys = /* @__PURE__ */ Object.create(null);
      let wasmURL = getFlag(options, keys, "wasmURL", mustBeStringOrURL);
      let wasmModule = getFlag(options, keys, "wasmModule", mustBeWebAssemblyModule);
      let worker = getFlag(options, keys, "worker", mustBeBoolean);
      checkForInvalidFlags(options, keys, "in initialize() call");
      return {
        wasmURL,
        wasmModule,
        worker
      };
    }
    function validateMangleCache(mangleCache) {
      let validated;
      if (mangleCache !== void 0) {
        validated = /* @__PURE__ */ Object.create(null);
        for (let key of Object.keys(mangleCache)) {
          let value = mangleCache[key];
          if (typeof value === "string" || value === false) {
            validated[key] = value;
          } else {
            throw new Error(`Expected ${JSON.stringify(key)} in mangle cache to map to either a string or false`);
          }
        }
      }
      return validated;
    }
    function pushLogFlags(flags, options, keys, isTTY2, logLevelDefault) {
      let color = getFlag(options, keys, "color", mustBeBoolean);
      let logLevel = getFlag(options, keys, "logLevel", mustBeString);
      let logLimit = getFlag(options, keys, "logLimit", mustBeInteger);
      if (color !== void 0)
        flags.push(`--color=${color}`);
      else if (isTTY2)
        flags.push(`--color=true`);
      flags.push(`--log-level=${logLevel || logLevelDefault}`);
      flags.push(`--log-limit=${logLimit || 0}`);
    }
    function pushCommonFlags(flags, options, keys) {
      let legalComments = getFlag(options, keys, "legalComments", mustBeString);
      let sourceRoot = getFlag(options, keys, "sourceRoot", mustBeString);
      let sourcesContent = getFlag(options, keys, "sourcesContent", mustBeBoolean);
      let target = getFlag(options, keys, "target", mustBeStringOrArray);
      let format = getFlag(options, keys, "format", mustBeString);
      let globalName = getFlag(options, keys, "globalName", mustBeString);
      let mangleProps = getFlag(options, keys, "mangleProps", mustBeRegExp);
      let reserveProps = getFlag(options, keys, "reserveProps", mustBeRegExp);
      let mangleQuoted = getFlag(options, keys, "mangleQuoted", mustBeBoolean);
      let minify = getFlag(options, keys, "minify", mustBeBoolean);
      let minifySyntax = getFlag(options, keys, "minifySyntax", mustBeBoolean);
      let minifyWhitespace = getFlag(options, keys, "minifyWhitespace", mustBeBoolean);
      let minifyIdentifiers = getFlag(options, keys, "minifyIdentifiers", mustBeBoolean);
      let drop = getFlag(options, keys, "drop", mustBeArray);
      let charset = getFlag(options, keys, "charset", mustBeString);
      let treeShaking = getFlag(options, keys, "treeShaking", mustBeBoolean);
      let ignoreAnnotations = getFlag(options, keys, "ignoreAnnotations", mustBeBoolean);
      let jsx = getFlag(options, keys, "jsx", mustBeString);
      let jsxFactory = getFlag(options, keys, "jsxFactory", mustBeString);
      let jsxFragment = getFlag(options, keys, "jsxFragment", mustBeString);
      let jsxImportSource = getFlag(options, keys, "jsxImportSource", mustBeString);
      let jsxDev = getFlag(options, keys, "jsxDev", mustBeBoolean);
      let jsxSideEffects = getFlag(options, keys, "jsxSideEffects", mustBeBoolean);
      let define = getFlag(options, keys, "define", mustBeObject);
      let logOverride = getFlag(options, keys, "logOverride", mustBeObject);
      let supported = getFlag(options, keys, "supported", mustBeObject);
      let pure = getFlag(options, keys, "pure", mustBeArray);
      let keepNames = getFlag(options, keys, "keepNames", mustBeBoolean);
      let platform = getFlag(options, keys, "platform", mustBeString);
      if (legalComments)
        flags.push(`--legal-comments=${legalComments}`);
      if (sourceRoot !== void 0)
        flags.push(`--source-root=${sourceRoot}`);
      if (sourcesContent !== void 0)
        flags.push(`--sources-content=${sourcesContent}`);
      if (target) {
        if (Array.isArray(target))
          flags.push(`--target=${Array.from(target).map(validateTarget).join(",")}`);
        else
          flags.push(`--target=${validateTarget(target)}`);
      }
      if (format)
        flags.push(`--format=${format}`);
      if (globalName)
        flags.push(`--global-name=${globalName}`);
      if (platform)
        flags.push(`--platform=${platform}`);
      if (minify)
        flags.push("--minify");
      if (minifySyntax)
        flags.push("--minify-syntax");
      if (minifyWhitespace)
        flags.push("--minify-whitespace");
      if (minifyIdentifiers)
        flags.push("--minify-identifiers");
      if (charset)
        flags.push(`--charset=${charset}`);
      if (treeShaking !== void 0)
        flags.push(`--tree-shaking=${treeShaking}`);
      if (ignoreAnnotations)
        flags.push(`--ignore-annotations`);
      if (drop)
        for (let what of drop)
          flags.push(`--drop:${what}`);
      if (mangleProps)
        flags.push(`--mangle-props=${mangleProps.source}`);
      if (reserveProps)
        flags.push(`--reserve-props=${reserveProps.source}`);
      if (mangleQuoted !== void 0)
        flags.push(`--mangle-quoted=${mangleQuoted}`);
      if (jsx)
        flags.push(`--jsx=${jsx}`);
      if (jsxFactory)
        flags.push(`--jsx-factory=${jsxFactory}`);
      if (jsxFragment)
        flags.push(`--jsx-fragment=${jsxFragment}`);
      if (jsxImportSource)
        flags.push(`--jsx-import-source=${jsxImportSource}`);
      if (jsxDev)
        flags.push(`--jsx-dev`);
      if (jsxSideEffects)
        flags.push(`--jsx-side-effects`);
      if (define) {
        for (let key in define) {
          if (key.indexOf("=") >= 0)
            throw new Error(`Invalid define: ${key}`);
          flags.push(`--define:${key}=${define[key]}`);
        }
      }
      if (logOverride) {
        for (let key in logOverride) {
          if (key.indexOf("=") >= 0)
            throw new Error(`Invalid log override: ${key}`);
          flags.push(`--log-override:${key}=${logOverride[key]}`);
        }
      }
      if (supported) {
        for (let key in supported) {
          if (key.indexOf("=") >= 0)
            throw new Error(`Invalid supported: ${key}`);
          flags.push(`--supported:${key}=${supported[key]}`);
        }
      }
      if (pure)
        for (let fn of pure)
          flags.push(`--pure:${fn}`);
      if (keepNames)
        flags.push(`--keep-names`);
    }
    function flagsForBuildOptions(callName, options, isTTY2, logLevelDefault, writeDefault) {
      var _a2;
      let flags = [];
      let entries = [];
      let keys = /* @__PURE__ */ Object.create(null);
      let stdinContents = null;
      let stdinResolveDir = null;
      let watchMode = null;
      pushLogFlags(flags, options, keys, isTTY2, logLevelDefault);
      pushCommonFlags(flags, options, keys);
      let sourcemap = getFlag(options, keys, "sourcemap", mustBeStringOrBoolean);
      let bundle = getFlag(options, keys, "bundle", mustBeBoolean);
      let watch = getFlag(options, keys, "watch", mustBeBooleanOrObject);
      let splitting = getFlag(options, keys, "splitting", mustBeBoolean);
      let preserveSymlinks = getFlag(options, keys, "preserveSymlinks", mustBeBoolean);
      let metafile = getFlag(options, keys, "metafile", mustBeBoolean);
      let outfile = getFlag(options, keys, "outfile", mustBeString);
      let outdir = getFlag(options, keys, "outdir", mustBeString);
      let outbase = getFlag(options, keys, "outbase", mustBeString);
      let tsconfig = getFlag(options, keys, "tsconfig", mustBeString);
      let resolveExtensions = getFlag(options, keys, "resolveExtensions", mustBeArray);
      let nodePathsInput = getFlag(options, keys, "nodePaths", mustBeArray);
      let mainFields = getFlag(options, keys, "mainFields", mustBeArray);
      let conditions = getFlag(options, keys, "conditions", mustBeArray);
      let external = getFlag(options, keys, "external", mustBeArray);
      let alias = getFlag(options, keys, "alias", mustBeObject);
      let loader = getFlag(options, keys, "loader", mustBeObject);
      let outExtension = getFlag(options, keys, "outExtension", mustBeObject);
      let publicPath = getFlag(options, keys, "publicPath", mustBeString);
      let entryNames = getFlag(options, keys, "entryNames", mustBeString);
      let chunkNames = getFlag(options, keys, "chunkNames", mustBeString);
      let assetNames = getFlag(options, keys, "assetNames", mustBeString);
      let inject = getFlag(options, keys, "inject", mustBeArray);
      let banner = getFlag(options, keys, "banner", mustBeObject);
      let footer = getFlag(options, keys, "footer", mustBeObject);
      let entryPoints = getFlag(options, keys, "entryPoints", mustBeArrayOrRecord);
      let absWorkingDir = getFlag(options, keys, "absWorkingDir", mustBeString);
      let stdin = getFlag(options, keys, "stdin", mustBeObject);
      let write = (_a2 = getFlag(options, keys, "write", mustBeBoolean)) != null ? _a2 : writeDefault;
      let allowOverwrite = getFlag(options, keys, "allowOverwrite", mustBeBoolean);
      let incremental = getFlag(options, keys, "incremental", mustBeBoolean) === true;
      let mangleCache = getFlag(options, keys, "mangleCache", mustBeObject);
      keys.plugins = true;
      checkForInvalidFlags(options, keys, `in ${callName}() call`);
      if (sourcemap)
        flags.push(`--sourcemap${sourcemap === true ? "" : `=${sourcemap}`}`);
      if (bundle)
        flags.push("--bundle");
      if (allowOverwrite)
        flags.push("--allow-overwrite");
      if (watch) {
        flags.push("--watch");
        if (typeof watch === "boolean") {
          watchMode = {};
        } else {
          let watchKeys = /* @__PURE__ */ Object.create(null);
          let onRebuild = getFlag(watch, watchKeys, "onRebuild", mustBeFunction);
          checkForInvalidFlags(watch, watchKeys, `on "watch" in ${callName}() call`);
          watchMode = { onRebuild };
        }
      }
      if (splitting)
        flags.push("--splitting");
      if (preserveSymlinks)
        flags.push("--preserve-symlinks");
      if (metafile)
        flags.push(`--metafile`);
      if (outfile)
        flags.push(`--outfile=${outfile}`);
      if (outdir)
        flags.push(`--outdir=${outdir}`);
      if (outbase)
        flags.push(`--outbase=${outbase}`);
      if (tsconfig)
        flags.push(`--tsconfig=${tsconfig}`);
      if (resolveExtensions) {
        let values = [];
        for (let value of resolveExtensions) {
          value += "";
          if (value.indexOf(",") >= 0)
            throw new Error(`Invalid resolve extension: ${value}`);
          values.push(value);
        }
        flags.push(`--resolve-extensions=${values.join(",")}`);
      }
      if (publicPath)
        flags.push(`--public-path=${publicPath}`);
      if (entryNames)
        flags.push(`--entry-names=${entryNames}`);
      if (chunkNames)
        flags.push(`--chunk-names=${chunkNames}`);
      if (assetNames)
        flags.push(`--asset-names=${assetNames}`);
      if (mainFields) {
        let values = [];
        for (let value of mainFields) {
          value += "";
          if (value.indexOf(",") >= 0)
            throw new Error(`Invalid main field: ${value}`);
          values.push(value);
        }
        flags.push(`--main-fields=${values.join(",")}`);
      }
      if (conditions) {
        let values = [];
        for (let value of conditions) {
          value += "";
          if (value.indexOf(",") >= 0)
            throw new Error(`Invalid condition: ${value}`);
          values.push(value);
        }
        flags.push(`--conditions=${values.join(",")}`);
      }
      if (external)
        for (let name of external)
          flags.push(`--external:${name}`);
      if (alias) {
        for (let old in alias) {
          if (old.indexOf("=") >= 0)
            throw new Error(`Invalid package name in alias: ${old}`);
          flags.push(`--alias:${old}=${alias[old]}`);
        }
      }
      if (banner) {
        for (let type in banner) {
          if (type.indexOf("=") >= 0)
            throw new Error(`Invalid banner file type: ${type}`);
          flags.push(`--banner:${type}=${banner[type]}`);
        }
      }
      if (footer) {
        for (let type in footer) {
          if (type.indexOf("=") >= 0)
            throw new Error(`Invalid footer file type: ${type}`);
          flags.push(`--footer:${type}=${footer[type]}`);
        }
      }
      if (inject)
        for (let path3 of inject)
          flags.push(`--inject:${path3}`);
      if (loader) {
        for (let ext in loader) {
          if (ext.indexOf("=") >= 0)
            throw new Error(`Invalid loader extension: ${ext}`);
          flags.push(`--loader:${ext}=${loader[ext]}`);
        }
      }
      if (outExtension) {
        for (let ext in outExtension) {
          if (ext.indexOf("=") >= 0)
            throw new Error(`Invalid out extension: ${ext}`);
          flags.push(`--out-extension:${ext}=${outExtension[ext]}`);
        }
      }
      if (entryPoints) {
        if (Array.isArray(entryPoints)) {
          for (let entryPoint of entryPoints) {
            entries.push(["", entryPoint + ""]);
          }
        } else {
          for (let [key, value] of Object.entries(entryPoints)) {
            entries.push([key + "", value + ""]);
          }
        }
      }
      if (stdin) {
        let stdinKeys = /* @__PURE__ */ Object.create(null);
        let contents = getFlag(stdin, stdinKeys, "contents", mustBeStringOrUint8Array);
        let resolveDir = getFlag(stdin, stdinKeys, "resolveDir", mustBeString);
        let sourcefile = getFlag(stdin, stdinKeys, "sourcefile", mustBeString);
        let loader2 = getFlag(stdin, stdinKeys, "loader", mustBeString);
        checkForInvalidFlags(stdin, stdinKeys, 'in "stdin" object');
        if (sourcefile)
          flags.push(`--sourcefile=${sourcefile}`);
        if (loader2)
          flags.push(`--loader=${loader2}`);
        if (resolveDir)
          stdinResolveDir = resolveDir + "";
        if (typeof contents === "string")
          stdinContents = encodeUTF8(contents);
        else if (contents instanceof Uint8Array)
          stdinContents = contents;
      }
      let nodePaths = [];
      if (nodePathsInput) {
        for (let value of nodePathsInput) {
          value += "";
          nodePaths.push(value);
        }
      }
      return {
        entries,
        flags,
        write,
        stdinContents,
        stdinResolveDir,
        absWorkingDir,
        incremental,
        nodePaths,
        watch: watchMode,
        mangleCache: validateMangleCache(mangleCache)
      };
    }
    function flagsForTransformOptions(callName, options, isTTY2, logLevelDefault) {
      let flags = [];
      let keys = /* @__PURE__ */ Object.create(null);
      pushLogFlags(flags, options, keys, isTTY2, logLevelDefault);
      pushCommonFlags(flags, options, keys);
      let sourcemap = getFlag(options, keys, "sourcemap", mustBeStringOrBoolean);
      let tsconfigRaw = getFlag(options, keys, "tsconfigRaw", mustBeStringOrObject);
      let sourcefile = getFlag(options, keys, "sourcefile", mustBeString);
      let loader = getFlag(options, keys, "loader", mustBeString);
      let banner = getFlag(options, keys, "banner", mustBeString);
      let footer = getFlag(options, keys, "footer", mustBeString);
      let mangleCache = getFlag(options, keys, "mangleCache", mustBeObject);
      checkForInvalidFlags(options, keys, `in ${callName}() call`);
      if (sourcemap)
        flags.push(`--sourcemap=${sourcemap === true ? "external" : sourcemap}`);
      if (tsconfigRaw)
        flags.push(`--tsconfig-raw=${typeof tsconfigRaw === "string" ? tsconfigRaw : JSON.stringify(tsconfigRaw)}`);
      if (sourcefile)
        flags.push(`--sourcefile=${sourcefile}`);
      if (loader)
        flags.push(`--loader=${loader}`);
      if (banner)
        flags.push(`--banner=${banner}`);
      if (footer)
        flags.push(`--footer=${footer}`);
      return {
        flags,
        mangleCache: validateMangleCache(mangleCache)
      };
    }
    function createChannel(streamIn) {
      const requestCallbacksByKey = {};
      const closeData = { didClose: false, reason: "" };
      let responseCallbacks = {};
      let nextRequestID = 0;
      let nextBuildKey = 0;
      let stdout = new Uint8Array(16 * 1024);
      let stdoutUsed = 0;
      let readFromStdout = (chunk) => {
        let limit = stdoutUsed + chunk.length;
        if (limit > stdout.length) {
          let swap = new Uint8Array(limit * 2);
          swap.set(stdout);
          stdout = swap;
        }
        stdout.set(chunk, stdoutUsed);
        stdoutUsed += chunk.length;
        let offset = 0;
        while (offset + 4 <= stdoutUsed) {
          let length = readUInt32LE(stdout, offset);
          if (offset + 4 + length > stdoutUsed) {
            break;
          }
          offset += 4;
          handleIncomingPacket(stdout.subarray(offset, offset + length));
          offset += length;
        }
        if (offset > 0) {
          stdout.copyWithin(0, offset, stdoutUsed);
          stdoutUsed -= offset;
        }
      };
      let afterClose = (error) => {
        closeData.didClose = true;
        if (error)
          closeData.reason = ": " + (error.message || error);
        const text = "The service was stopped" + closeData.reason;
        for (let id in responseCallbacks) {
          responseCallbacks[id](text, null);
        }
        responseCallbacks = {};
      };
      let sendRequest = (refs, value, callback) => {
        if (closeData.didClose)
          return callback("The service is no longer running" + closeData.reason, null);
        let id = nextRequestID++;
        responseCallbacks[id] = (error, response) => {
          try {
            callback(error, response);
          } finally {
            if (refs)
              refs.unref();
          }
        };
        if (refs)
          refs.ref();
        streamIn.writeToStdin(encodePacket({ id, isRequest: true, value }));
      };
      let sendResponse = (id, value) => {
        if (closeData.didClose)
          throw new Error("The service is no longer running" + closeData.reason);
        streamIn.writeToStdin(encodePacket({ id, isRequest: false, value }));
      };
      let handleRequest = async (id, request) => {
        try {
          if (request.command === "ping") {
            sendResponse(id, {});
            return;
          }
          if (typeof request.key === "number") {
            const requestCallbacks = requestCallbacksByKey[request.key];
            if (requestCallbacks) {
              const callback = requestCallbacks[request.command];
              if (callback) {
                await callback(id, request);
                return;
              }
            }
          }
          throw new Error(`Invalid command: ` + request.command);
        } catch (e) {
          sendResponse(id, { errors: [extractErrorMessageV8(e, streamIn, null, void 0, "")] });
        }
      };
      let isFirstPacket = true;
      let handleIncomingPacket = (bytes) => {
        if (isFirstPacket) {
          isFirstPacket = false;
          let binaryVersion = String.fromCharCode(...bytes);
          if (binaryVersion !== "0.15.18") {
            throw new Error(`Cannot start service: Host version "${"0.15.18"}" does not match binary version ${JSON.stringify(binaryVersion)}`);
          }
          return;
        }
        let packet = decodePacket(bytes);
        if (packet.isRequest) {
          handleRequest(packet.id, packet.value);
        } else {
          let callback = responseCallbacks[packet.id];
          delete responseCallbacks[packet.id];
          if (packet.value.error)
            callback(packet.value.error, {});
          else
            callback(null, packet.value);
        }
      };
      let buildOrServe = ({ callName, refs, serveOptions, options, isTTY: isTTY2, defaultWD: defaultWD2, callback }) => {
        let refCount = 0;
        const buildKey = nextBuildKey++;
        const requestCallbacks = {};
        const buildRefs = {
          ref() {
            if (++refCount === 1) {
              if (refs)
                refs.ref();
            }
          },
          unref() {
            if (--refCount === 0) {
              delete requestCallbacksByKey[buildKey];
              if (refs)
                refs.unref();
            }
          }
        };
        requestCallbacksByKey[buildKey] = requestCallbacks;
        buildRefs.ref();
        buildOrServeImpl(callName, buildKey, sendRequest, sendResponse, buildRefs, streamIn, requestCallbacks, options, serveOptions, isTTY2, defaultWD2, closeData, (err, res) => {
          try {
            callback(err, res);
          } finally {
            buildRefs.unref();
          }
        });
      };
      let transform2 = ({ callName, refs, input, options, isTTY: isTTY2, fs: fs3, callback }) => {
        const details = createObjectStash();
        let start = (inputPath) => {
          try {
            if (typeof input !== "string" && !(input instanceof Uint8Array))
              throw new Error('The input to "transform" must be a string or a Uint8Array');
            let {
              flags,
              mangleCache
            } = flagsForTransformOptions(callName, options, isTTY2, transformLogLevelDefault);
            let request = {
              command: "transform",
              flags,
              inputFS: inputPath !== null,
              input: inputPath !== null ? encodeUTF8(inputPath) : typeof input === "string" ? encodeUTF8(input) : input
            };
            if (mangleCache)
              request.mangleCache = mangleCache;
            sendRequest(refs, request, (error, response) => {
              if (error)
                return callback(new Error(error), null);
              let errors = replaceDetailsInMessages(response.errors, details);
              let warnings = replaceDetailsInMessages(response.warnings, details);
              let outstanding = 1;
              let next = () => {
                if (--outstanding === 0) {
                  let result = { warnings, code: response.code, map: response.map };
                  if (response.mangleCache)
                    result.mangleCache = response == null ? void 0 : response.mangleCache;
                  callback(null, result);
                }
              };
              if (errors.length > 0)
                return callback(failureErrorWithLog("Transform failed", errors, warnings), null);
              if (response.codeFS) {
                outstanding++;
                fs3.readFile(response.code, (err, contents) => {
                  if (err !== null) {
                    callback(err, null);
                  } else {
                    response.code = contents;
                    next();
                  }
                });
              }
              if (response.mapFS) {
                outstanding++;
                fs3.readFile(response.map, (err, contents) => {
                  if (err !== null) {
                    callback(err, null);
                  } else {
                    response.map = contents;
                    next();
                  }
                });
              }
              next();
            });
          } catch (e) {
            let flags = [];
            try {
              pushLogFlags(flags, options, {}, isTTY2, transformLogLevelDefault);
            } catch {
            }
            const error = extractErrorMessageV8(e, streamIn, details, void 0, "");
            sendRequest(refs, { command: "error", flags, error }, () => {
              error.detail = details.load(error.detail);
              callback(failureErrorWithLog("Transform failed", [error], []), null);
            });
          }
        };
        if ((typeof input === "string" || input instanceof Uint8Array) && input.length > 1024 * 1024) {
          let next = start;
          start = () => fs3.writeFile(input, next);
        }
        start(null);
      };
      let formatMessages2 = ({ callName, refs, messages, options, callback }) => {
        let result = sanitizeMessages(messages, "messages", null, "");
        if (!options)
          throw new Error(`Missing second argument in ${callName}() call`);
        let keys = {};
        let kind = getFlag(options, keys, "kind", mustBeString);
        let color = getFlag(options, keys, "color", mustBeBoolean);
        let terminalWidth = getFlag(options, keys, "terminalWidth", mustBeInteger);
        checkForInvalidFlags(options, keys, `in ${callName}() call`);
        if (kind === void 0)
          throw new Error(`Missing "kind" in ${callName}() call`);
        if (kind !== "error" && kind !== "warning")
          throw new Error(`Expected "kind" to be "error" or "warning" in ${callName}() call`);
        let request = {
          command: "format-msgs",
          messages: result,
          isWarning: kind === "warning"
        };
        if (color !== void 0)
          request.color = color;
        if (terminalWidth !== void 0)
          request.terminalWidth = terminalWidth;
        sendRequest(refs, request, (error, response) => {
          if (error)
            return callback(new Error(error), null);
          callback(null, response.messages);
        });
      };
      let analyzeMetafile2 = ({ callName, refs, metafile, options, callback }) => {
        if (options === void 0)
          options = {};
        let keys = {};
        let color = getFlag(options, keys, "color", mustBeBoolean);
        let verbose = getFlag(options, keys, "verbose", mustBeBoolean);
        checkForInvalidFlags(options, keys, `in ${callName}() call`);
        let request = {
          command: "analyze-metafile",
          metafile
        };
        if (color !== void 0)
          request.color = color;
        if (verbose !== void 0)
          request.verbose = verbose;
        sendRequest(refs, request, (error, response) => {
          if (error)
            return callback(new Error(error), null);
          callback(null, response.result);
        });
      };
      return {
        readFromStdout,
        afterClose,
        service: {
          buildOrServe,
          transform: transform2,
          formatMessages: formatMessages2,
          analyzeMetafile: analyzeMetafile2
        }
      };
    }
    function buildOrServeImpl(callName, buildKey, sendRequest, sendResponse, refs, streamIn, requestCallbacks, options, serveOptions, isTTY2, defaultWD2, closeData, callback) {
      const details = createObjectStash();
      const logPluginError = (e, pluginName, note, done) => {
        const flags = [];
        try {
          pushLogFlags(flags, options, {}, isTTY2, buildLogLevelDefault);
        } catch {
        }
        const message = extractErrorMessageV8(e, streamIn, details, note, pluginName);
        sendRequest(refs, { command: "error", flags, error: message }, () => {
          message.detail = details.load(message.detail);
          done(message);
        });
      };
      const handleError = (e, pluginName) => {
        logPluginError(e, pluginName, void 0, (error) => {
          callback(failureErrorWithLog("Build failed", [error], []), null);
        });
      };
      let plugins;
      if (typeof options === "object") {
        const value = options.plugins;
        if (value !== void 0) {
          if (!Array.isArray(value))
            throw new Error(`"plugins" must be an array`);
          plugins = value;
        }
      }
      if (plugins && plugins.length > 0) {
        if (streamIn.isSync) {
          handleError(new Error("Cannot use plugins in synchronous API calls"), "");
          return;
        }
        handlePlugins(buildKey, sendRequest, sendResponse, refs, streamIn, requestCallbacks, options, plugins, details).then((result) => {
          if (!result.ok) {
            handleError(result.error, result.pluginName);
            return;
          }
          try {
            buildOrServeContinue(result.requestPlugins, result.runOnEndCallbacks);
          } catch (e) {
            handleError(e, "");
          }
        }, (e) => handleError(e, ""));
        return;
      }
      try {
        buildOrServeContinue(null, (result, logPluginError2, done) => done());
      } catch (e) {
        handleError(e, "");
      }
      function buildOrServeContinue(requestPlugins, runOnEndCallbacks) {
        let writeDefault = !streamIn.isWriteUnavailable;
        let {
          entries,
          flags,
          write,
          stdinContents,
          stdinResolveDir,
          absWorkingDir,
          incremental,
          nodePaths,
          watch,
          mangleCache
        } = flagsForBuildOptions(callName, options, isTTY2, buildLogLevelDefault, writeDefault);
        let request = {
          command: "build",
          key: buildKey,
          entries,
          flags,
          write,
          stdinContents,
          stdinResolveDir,
          absWorkingDir: absWorkingDir || defaultWD2,
          incremental,
          nodePaths
        };
        if (requestPlugins)
          request.plugins = requestPlugins;
        if (mangleCache)
          request.mangleCache = mangleCache;
        let serve2 = serveOptions && buildServeData(buildKey, sendRequest, sendResponse, refs, requestCallbacks, serveOptions, request);
        let rebuild;
        let stop;
        let copyResponseToResult = (response, result) => {
          if (response.outputFiles)
            result.outputFiles = response.outputFiles.map(convertOutputFiles);
          if (response.metafile)
            result.metafile = JSON.parse(response.metafile);
          if (response.mangleCache)
            result.mangleCache = response.mangleCache;
          if (response.writeToStdout !== void 0)
            console.log(decodeUTF8(response.writeToStdout).replace(/\n$/, ""));
        };
        let buildResponseToResult = (response, callback2) => {
          let result = {
            errors: replaceDetailsInMessages(response.errors, details),
            warnings: replaceDetailsInMessages(response.warnings, details)
          };
          copyResponseToResult(response, result);
          runOnEndCallbacks(result, logPluginError, () => {
            if (result.errors.length > 0) {
              return callback2(failureErrorWithLog("Build failed", result.errors, result.warnings), null);
            }
            if (response.rebuild) {
              if (!rebuild) {
                let isDisposed = false;
                rebuild = () => new Promise((resolve, reject) => {
                  if (isDisposed || closeData.didClose)
                    throw new Error("Cannot rebuild");
                  sendRequest(refs, { command: "rebuild", key: buildKey }, (error2, response2) => {
                    if (error2) {
                      const message = { id: "", pluginName: "", text: error2, location: null, notes: [], detail: void 0 };
                      return callback2(failureErrorWithLog("Build failed", [message], []), null);
                    }
                    buildResponseToResult(response2, (error3, result3) => {
                      if (error3)
                        reject(error3);
                      else
                        resolve(result3);
                    });
                  });
                });
                refs.ref();
                rebuild.dispose = () => {
                  if (isDisposed)
                    return;
                  isDisposed = true;
                  sendRequest(refs, { command: "rebuild-dispose", key: buildKey }, () => {
                  });
                  refs.unref();
                };
              }
              result.rebuild = rebuild;
            }
            if (response.watch) {
              if (!stop) {
                let isStopped = false;
                refs.ref();
                stop = () => {
                  if (isStopped)
                    return;
                  isStopped = true;
                  delete requestCallbacks["watch-rebuild"];
                  sendRequest(refs, { command: "watch-stop", key: buildKey }, () => {
                  });
                  refs.unref();
                };
                if (watch) {
                  requestCallbacks["watch-rebuild"] = (id, request2) => {
                    try {
                      let watchResponse = request2.args;
                      let result2 = {
                        errors: replaceDetailsInMessages(watchResponse.errors, details),
                        warnings: replaceDetailsInMessages(watchResponse.warnings, details)
                      };
                      copyResponseToResult(watchResponse, result2);
                      runOnEndCallbacks(result2, logPluginError, () => {
                        if (result2.errors.length > 0) {
                          if (watch.onRebuild)
                            watch.onRebuild(failureErrorWithLog("Build failed", result2.errors, result2.warnings), null);
                          return;
                        }
                        result2.stop = stop;
                        if (watch.onRebuild)
                          watch.onRebuild(null, result2);
                      });
                    } catch (err) {
                      console.error(err);
                    }
                    sendResponse(id, {});
                  };
                }
              }
              result.stop = stop;
            }
            callback2(null, result);
          });
        };
        if (write && streamIn.isWriteUnavailable)
          throw new Error(`The "write" option is unavailable in this environment`);
        if (incremental && streamIn.isSync)
          throw new Error(`Cannot use "incremental" with a synchronous build`);
        if (watch && streamIn.isSync)
          throw new Error(`Cannot use "watch" with a synchronous build`);
        sendRequest(refs, request, (error, response) => {
          if (error)
            return callback(new Error(error), null);
          if (serve2) {
            let serveResponse = response;
            let isStopped = false;
            refs.ref();
            let result = {
              port: serveResponse.port,
              host: serveResponse.host,
              wait: serve2.wait,
              stop() {
                if (isStopped)
                  return;
                isStopped = true;
                serve2.stop();
                refs.unref();
              }
            };
            refs.ref();
            serve2.wait.then(refs.unref, refs.unref);
            return callback(null, result);
          }
          return buildResponseToResult(response, callback);
        });
      }
    }
    var buildServeData = (buildKey, sendRequest, sendResponse, refs, requestCallbacks, options, request) => {
      let keys = {};
      let port = getFlag(options, keys, "port", mustBeInteger);
      let host = getFlag(options, keys, "host", mustBeString);
      let servedir = getFlag(options, keys, "servedir", mustBeString);
      let onRequest = getFlag(options, keys, "onRequest", mustBeFunction);
      let wait = new Promise((resolve, reject) => {
        requestCallbacks["serve-wait"] = (id, request2) => {
          if (request2.error !== null)
            reject(new Error(request2.error));
          else
            resolve();
          sendResponse(id, {});
        };
      });
      request.serve = {};
      checkForInvalidFlags(options, keys, `in serve() call`);
      if (port !== void 0)
        request.serve.port = port;
      if (host !== void 0)
        request.serve.host = host;
      if (servedir !== void 0)
        request.serve.servedir = servedir;
      requestCallbacks["serve-request"] = (id, request2) => {
        if (onRequest)
          onRequest(request2.args);
        sendResponse(id, {});
      };
      return {
        wait,
        stop() {
          sendRequest(refs, { command: "serve-stop", key: buildKey }, () => {
          });
        }
      };
    };
    var handlePlugins = async (buildKey, sendRequest, sendResponse, refs, streamIn, requestCallbacks, initialOptions, plugins, details) => {
      let onStartCallbacks = [];
      let onEndCallbacks = [];
      let onResolveCallbacks = {};
      let onLoadCallbacks = {};
      let nextCallbackID = 0;
      let i = 0;
      let requestPlugins = [];
      let isSetupDone = false;
      plugins = [...plugins];
      for (let item of plugins) {
        let keys = {};
        if (typeof item !== "object")
          throw new Error(`Plugin at index ${i} must be an object`);
        const name = getFlag(item, keys, "name", mustBeString);
        if (typeof name !== "string" || name === "")
          throw new Error(`Plugin at index ${i} is missing a name`);
        try {
          let setup = getFlag(item, keys, "setup", mustBeFunction);
          if (typeof setup !== "function")
            throw new Error(`Plugin is missing a setup function`);
          checkForInvalidFlags(item, keys, `on plugin ${JSON.stringify(name)}`);
          let plugin = {
            name,
            onResolve: [],
            onLoad: []
          };
          i++;
          let resolve = (path3, options = {}) => {
            if (!isSetupDone)
              throw new Error('Cannot call "resolve" before plugin setup has completed');
            if (typeof path3 !== "string")
              throw new Error(`The path to resolve must be a string`);
            let keys2 = /* @__PURE__ */ Object.create(null);
            let pluginName = getFlag(options, keys2, "pluginName", mustBeString);
            let importer = getFlag(options, keys2, "importer", mustBeString);
            let namespace = getFlag(options, keys2, "namespace", mustBeString);
            let resolveDir = getFlag(options, keys2, "resolveDir", mustBeString);
            let kind = getFlag(options, keys2, "kind", mustBeString);
            let pluginData = getFlag(options, keys2, "pluginData", canBeAnything);
            checkForInvalidFlags(options, keys2, "in resolve() call");
            return new Promise((resolve2, reject) => {
              const request = {
                command: "resolve",
                path: path3,
                key: buildKey,
                pluginName: name
              };
              if (pluginName != null)
                request.pluginName = pluginName;
              if (importer != null)
                request.importer = importer;
              if (namespace != null)
                request.namespace = namespace;
              if (resolveDir != null)
                request.resolveDir = resolveDir;
              if (kind != null)
                request.kind = kind;
              if (pluginData != null)
                request.pluginData = details.store(pluginData);
              sendRequest(refs, request, (error, response) => {
                if (error !== null)
                  reject(new Error(error));
                else
                  resolve2({
                    errors: replaceDetailsInMessages(response.errors, details),
                    warnings: replaceDetailsInMessages(response.warnings, details),
                    path: response.path,
                    external: response.external,
                    sideEffects: response.sideEffects,
                    namespace: response.namespace,
                    suffix: response.suffix,
                    pluginData: details.load(response.pluginData)
                  });
              });
            });
          };
          let promise = setup({
            initialOptions,
            resolve,
            onStart(callback) {
              let registeredText = `This error came from the "onStart" callback registered here:`;
              let registeredNote = extractCallerV8(new Error(registeredText), streamIn, "onStart");
              onStartCallbacks.push({ name, callback, note: registeredNote });
            },
            onEnd(callback) {
              let registeredText = `This error came from the "onEnd" callback registered here:`;
              let registeredNote = extractCallerV8(new Error(registeredText), streamIn, "onEnd");
              onEndCallbacks.push({ name, callback, note: registeredNote });
            },
            onResolve(options, callback) {
              let registeredText = `This error came from the "onResolve" callback registered here:`;
              let registeredNote = extractCallerV8(new Error(registeredText), streamIn, "onResolve");
              let keys2 = {};
              let filter = getFlag(options, keys2, "filter", mustBeRegExp);
              let namespace = getFlag(options, keys2, "namespace", mustBeString);
              checkForInvalidFlags(options, keys2, `in onResolve() call for plugin ${JSON.stringify(name)}`);
              if (filter == null)
                throw new Error(`onResolve() call is missing a filter`);
              let id = nextCallbackID++;
              onResolveCallbacks[id] = { name, callback, note: registeredNote };
              plugin.onResolve.push({ id, filter: filter.source, namespace: namespace || "" });
            },
            onLoad(options, callback) {
              let registeredText = `This error came from the "onLoad" callback registered here:`;
              let registeredNote = extractCallerV8(new Error(registeredText), streamIn, "onLoad");
              let keys2 = {};
              let filter = getFlag(options, keys2, "filter", mustBeRegExp);
              let namespace = getFlag(options, keys2, "namespace", mustBeString);
              checkForInvalidFlags(options, keys2, `in onLoad() call for plugin ${JSON.stringify(name)}`);
              if (filter == null)
                throw new Error(`onLoad() call is missing a filter`);
              let id = nextCallbackID++;
              onLoadCallbacks[id] = { name, callback, note: registeredNote };
              plugin.onLoad.push({ id, filter: filter.source, namespace: namespace || "" });
            },
            esbuild: streamIn.esbuild
          });
          if (promise)
            await promise;
          requestPlugins.push(plugin);
        } catch (e) {
          return { ok: false, error: e, pluginName: name };
        }
      }
      requestCallbacks["on-start"] = async (id, request) => {
        let response = { errors: [], warnings: [] };
        await Promise.all(onStartCallbacks.map(async ({ name, callback, note }) => {
          try {
            let result = await callback();
            if (result != null) {
              if (typeof result !== "object")
                throw new Error(`Expected onStart() callback in plugin ${JSON.stringify(name)} to return an object`);
              let keys = {};
              let errors = getFlag(result, keys, "errors", mustBeArray);
              let warnings = getFlag(result, keys, "warnings", mustBeArray);
              checkForInvalidFlags(result, keys, `from onStart() callback in plugin ${JSON.stringify(name)}`);
              if (errors != null)
                response.errors.push(...sanitizeMessages(errors, "errors", details, name));
              if (warnings != null)
                response.warnings.push(...sanitizeMessages(warnings, "warnings", details, name));
            }
          } catch (e) {
            response.errors.push(extractErrorMessageV8(e, streamIn, details, note && note(), name));
          }
        }));
        sendResponse(id, response);
      };
      requestCallbacks["on-resolve"] = async (id, request) => {
        let response = {}, name = "", callback, note;
        for (let id2 of request.ids) {
          try {
            ({ name, callback, note } = onResolveCallbacks[id2]);
            let result = await callback({
              path: request.path,
              importer: request.importer,
              namespace: request.namespace,
              resolveDir: request.resolveDir,
              kind: request.kind,
              pluginData: details.load(request.pluginData)
            });
            if (result != null) {
              if (typeof result !== "object")
                throw new Error(`Expected onResolve() callback in plugin ${JSON.stringify(name)} to return an object`);
              let keys = {};
              let pluginName = getFlag(result, keys, "pluginName", mustBeString);
              let path3 = getFlag(result, keys, "path", mustBeString);
              let namespace = getFlag(result, keys, "namespace", mustBeString);
              let suffix = getFlag(result, keys, "suffix", mustBeString);
              let external = getFlag(result, keys, "external", mustBeBoolean);
              let sideEffects = getFlag(result, keys, "sideEffects", mustBeBoolean);
              let pluginData = getFlag(result, keys, "pluginData", canBeAnything);
              let errors = getFlag(result, keys, "errors", mustBeArray);
              let warnings = getFlag(result, keys, "warnings", mustBeArray);
              let watchFiles = getFlag(result, keys, "watchFiles", mustBeArray);
              let watchDirs = getFlag(result, keys, "watchDirs", mustBeArray);
              checkForInvalidFlags(result, keys, `from onResolve() callback in plugin ${JSON.stringify(name)}`);
              response.id = id2;
              if (pluginName != null)
                response.pluginName = pluginName;
              if (path3 != null)
                response.path = path3;
              if (namespace != null)
                response.namespace = namespace;
              if (suffix != null)
                response.suffix = suffix;
              if (external != null)
                response.external = external;
              if (sideEffects != null)
                response.sideEffects = sideEffects;
              if (pluginData != null)
                response.pluginData = details.store(pluginData);
              if (errors != null)
                response.errors = sanitizeMessages(errors, "errors", details, name);
              if (warnings != null)
                response.warnings = sanitizeMessages(warnings, "warnings", details, name);
              if (watchFiles != null)
                response.watchFiles = sanitizeStringArray(watchFiles, "watchFiles");
              if (watchDirs != null)
                response.watchDirs = sanitizeStringArray(watchDirs, "watchDirs");
              break;
            }
          } catch (e) {
            response = { id: id2, errors: [extractErrorMessageV8(e, streamIn, details, note && note(), name)] };
            break;
          }
        }
        sendResponse(id, response);
      };
      requestCallbacks["on-load"] = async (id, request) => {
        let response = {}, name = "", callback, note;
        for (let id2 of request.ids) {
          try {
            ({ name, callback, note } = onLoadCallbacks[id2]);
            let result = await callback({
              path: request.path,
              namespace: request.namespace,
              suffix: request.suffix,
              pluginData: details.load(request.pluginData)
            });
            if (result != null) {
              if (typeof result !== "object")
                throw new Error(`Expected onLoad() callback in plugin ${JSON.stringify(name)} to return an object`);
              let keys = {};
              let pluginName = getFlag(result, keys, "pluginName", mustBeString);
              let contents = getFlag(result, keys, "contents", mustBeStringOrUint8Array);
              let resolveDir = getFlag(result, keys, "resolveDir", mustBeString);
              let pluginData = getFlag(result, keys, "pluginData", canBeAnything);
              let loader = getFlag(result, keys, "loader", mustBeString);
              let errors = getFlag(result, keys, "errors", mustBeArray);
              let warnings = getFlag(result, keys, "warnings", mustBeArray);
              let watchFiles = getFlag(result, keys, "watchFiles", mustBeArray);
              let watchDirs = getFlag(result, keys, "watchDirs", mustBeArray);
              checkForInvalidFlags(result, keys, `from onLoad() callback in plugin ${JSON.stringify(name)}`);
              response.id = id2;
              if (pluginName != null)
                response.pluginName = pluginName;
              if (contents instanceof Uint8Array)
                response.contents = contents;
              else if (contents != null)
                response.contents = encodeUTF8(contents);
              if (resolveDir != null)
                response.resolveDir = resolveDir;
              if (pluginData != null)
                response.pluginData = details.store(pluginData);
              if (loader != null)
                response.loader = loader;
              if (errors != null)
                response.errors = sanitizeMessages(errors, "errors", details, name);
              if (warnings != null)
                response.warnings = sanitizeMessages(warnings, "warnings", details, name);
              if (watchFiles != null)
                response.watchFiles = sanitizeStringArray(watchFiles, "watchFiles");
              if (watchDirs != null)
                response.watchDirs = sanitizeStringArray(watchDirs, "watchDirs");
              break;
            }
          } catch (e) {
            response = { id: id2, errors: [extractErrorMessageV8(e, streamIn, details, note && note(), name)] };
            break;
          }
        }
        sendResponse(id, response);
      };
      let runOnEndCallbacks = (result, logPluginError, done) => done();
      if (onEndCallbacks.length > 0) {
        runOnEndCallbacks = (result, logPluginError, done) => {
          (async () => {
            for (const { name, callback, note } of onEndCallbacks) {
              try {
                await callback(result);
              } catch (e) {
                result.errors.push(await new Promise((resolve) => logPluginError(e, name, note && note(), resolve)));
              }
            }
          })().then(done);
        };
      }
      isSetupDone = true;
      return {
        ok: true,
        requestPlugins,
        runOnEndCallbacks
      };
    };
    function createObjectStash() {
      const map = /* @__PURE__ */ new Map();
      let nextID = 0;
      return {
        load(id) {
          return map.get(id);
        },
        store(value) {
          if (value === void 0)
            return -1;
          const id = nextID++;
          map.set(id, value);
          return id;
        }
      };
    }
    function extractCallerV8(e, streamIn, ident) {
      let note;
      let tried = false;
      return () => {
        if (tried)
          return note;
        tried = true;
        try {
          let lines = (e.stack + "").split("\n");
          lines.splice(1, 1);
          let location = parseStackLinesV8(streamIn, lines, ident);
          if (location) {
            note = { text: e.message, location };
            return note;
          }
        } catch {
        }
      };
    }
    function extractErrorMessageV8(e, streamIn, stash, note, pluginName) {
      let text = "Internal error";
      let location = null;
      try {
        text = (e && e.message || e) + "";
      } catch {
      }
      try {
        location = parseStackLinesV8(streamIn, (e.stack + "").split("\n"), "");
      } catch {
      }
      return { id: "", pluginName, text, location, notes: note ? [note] : [], detail: stash ? stash.store(e) : -1 };
    }
    function parseStackLinesV8(streamIn, lines, ident) {
      let at2 = "    at ";
      if (streamIn.readFileSync && !lines[0].startsWith(at2) && lines[1].startsWith(at2)) {
        for (let i = 1; i < lines.length; i++) {
          let line = lines[i];
          if (!line.startsWith(at2))
            continue;
          line = line.slice(at2.length);
          while (true) {
            let match = /^(?:new |async )?\S+ \((.*)\)$/.exec(line);
            if (match) {
              line = match[1];
              continue;
            }
            match = /^eval at \S+ \((.*)\)(?:, \S+:\d+:\d+)?$/.exec(line);
            if (match) {
              line = match[1];
              continue;
            }
            match = /^(\S+):(\d+):(\d+)$/.exec(line);
            if (match) {
              let contents;
              try {
                contents = streamIn.readFileSync(match[1], "utf8");
              } catch {
                break;
              }
              let lineText = contents.split(/\r\n|\r|\n|\u2028|\u2029/)[+match[2] - 1] || "";
              let column = +match[3] - 1;
              let length = lineText.slice(column, column + ident.length) === ident ? ident.length : 0;
              return {
                file: match[1],
                namespace: "file",
                line: +match[2],
                column: encodeUTF8(lineText.slice(0, column)).length,
                length: encodeUTF8(lineText.slice(column, column + length)).length,
                lineText: lineText + "\n" + lines.slice(1).join("\n"),
                suggestion: ""
              };
            }
            break;
          }
        }
      }
      return null;
    }
    function failureErrorWithLog(text, errors, warnings) {
      let limit = 5;
      let summary = errors.length < 1 ? "" : ` with ${errors.length} error${errors.length < 2 ? "" : "s"}:` + errors.slice(0, limit + 1).map((e, i) => {
        if (i === limit)
          return "\n...";
        if (!e.location)
          return `
error: ${e.text}`;
        let { file, line, column } = e.location;
        let pluginText = e.pluginName ? `[plugin: ${e.pluginName}] ` : "";
        return `
${file}:${line}:${column}: ERROR: ${pluginText}${e.text}`;
      }).join("");
      let error = new Error(`${text}${summary}`);
      error.errors = errors;
      error.warnings = warnings;
      return error;
    }
    function replaceDetailsInMessages(messages, stash) {
      for (const message of messages) {
        message.detail = stash.load(message.detail);
      }
      return messages;
    }
    function sanitizeLocation(location, where) {
      if (location == null)
        return null;
      let keys = {};
      let file = getFlag(location, keys, "file", mustBeString);
      let namespace = getFlag(location, keys, "namespace", mustBeString);
      let line = getFlag(location, keys, "line", mustBeInteger);
      let column = getFlag(location, keys, "column", mustBeInteger);
      let length = getFlag(location, keys, "length", mustBeInteger);
      let lineText = getFlag(location, keys, "lineText", mustBeString);
      let suggestion = getFlag(location, keys, "suggestion", mustBeString);
      checkForInvalidFlags(location, keys, where);
      return {
        file: file || "",
        namespace: namespace || "",
        line: line || 0,
        column: column || 0,
        length: length || 0,
        lineText: lineText || "",
        suggestion: suggestion || ""
      };
    }
    function sanitizeMessages(messages, property, stash, fallbackPluginName) {
      let messagesClone = [];
      let index = 0;
      for (const message of messages) {
        let keys = {};
        let id = getFlag(message, keys, "id", mustBeString);
        let pluginName = getFlag(message, keys, "pluginName", mustBeString);
        let text = getFlag(message, keys, "text", mustBeString);
        let location = getFlag(message, keys, "location", mustBeObjectOrNull);
        let notes = getFlag(message, keys, "notes", mustBeArray);
        let detail = getFlag(message, keys, "detail", canBeAnything);
        let where = `in element ${index} of "${property}"`;
        checkForInvalidFlags(message, keys, where);
        let notesClone = [];
        if (notes) {
          for (const note of notes) {
            let noteKeys = {};
            let noteText = getFlag(note, noteKeys, "text", mustBeString);
            let noteLocation = getFlag(note, noteKeys, "location", mustBeObjectOrNull);
            checkForInvalidFlags(note, noteKeys, where);
            notesClone.push({
              text: noteText || "",
              location: sanitizeLocation(noteLocation, where)
            });
          }
        }
        messagesClone.push({
          id: id || "",
          pluginName: pluginName || fallbackPluginName,
          text: text || "",
          location: sanitizeLocation(location, where),
          notes: notesClone,
          detail: stash ? stash.store(detail) : -1
        });
        index++;
      }
      return messagesClone;
    }
    function sanitizeStringArray(values, property) {
      const result = [];
      for (const value of values) {
        if (typeof value !== "string")
          throw new Error(`${JSON.stringify(property)} must be an array of strings`);
        result.push(value);
      }
      return result;
    }
    function convertOutputFiles({ path: path3, contents }) {
      let text = null;
      return {
        path: path3,
        contents,
        get text() {
          const binary = this.contents;
          if (text === null || binary !== contents) {
            contents = binary;
            text = decodeUTF8(binary);
          }
          return text;
        }
      };
    }
    var fs = require("fs");
    var os = require("os");
    var path = require("path");
    var ESBUILD_BINARY_PATH = process.env.ESBUILD_BINARY_PATH || ESBUILD_BINARY_PATH;
    var packageDarwin_arm64 = "esbuild-darwin-arm64";
    var packageDarwin_x64 = "esbuild-darwin-64";
    var knownWindowsPackages = {
      "win32 arm64 LE": "esbuild-windows-arm64",
      "win32 ia32 LE": "esbuild-windows-32",
      "win32 x64 LE": "esbuild-windows-64"
    };
    var knownUnixlikePackages = {
      "android arm64 LE": "esbuild-android-arm64",
      "darwin arm64 LE": "esbuild-darwin-arm64",
      "darwin x64 LE": "esbuild-darwin-64",
      "freebsd arm64 LE": "esbuild-freebsd-arm64",
      "freebsd x64 LE": "esbuild-freebsd-64",
      "linux arm LE": "esbuild-linux-arm",
      "linux arm64 LE": "esbuild-linux-arm64",
      "linux ia32 LE": "esbuild-linux-32",
      "linux mips64el LE": "esbuild-linux-mips64le",
      "linux ppc64 LE": "esbuild-linux-ppc64le",
      "linux riscv64 LE": "esbuild-linux-riscv64",
      "linux s390x BE": "esbuild-linux-s390x",
      "linux x64 LE": "esbuild-linux-64",
      "linux loong64 LE": "@esbuild/linux-loong64",
      "netbsd x64 LE": "esbuild-netbsd-64",
      "openbsd x64 LE": "esbuild-openbsd-64",
      "sunos x64 LE": "esbuild-sunos-64"
    };
    var knownWebAssemblyFallbackPackages = {
      "android arm LE": "@esbuild/android-arm",
      "android x64 LE": "esbuild-android-64"
    };
    function pkgAndSubpathForCurrentPlatform() {
      let pkg;
      let subpath;
      let isWASM = false;
      let platformKey = `${process.platform} ${os.arch()} ${os.endianness()}`;
      if (platformKey in knownWindowsPackages) {
        pkg = knownWindowsPackages[platformKey];
        subpath = "esbuild.exe";
      } else if (platformKey in knownUnixlikePackages) {
        pkg = knownUnixlikePackages[platformKey];
        subpath = "bin/esbuild";
      } else if (platformKey in knownWebAssemblyFallbackPackages) {
        pkg = knownWebAssemblyFallbackPackages[platformKey];
        subpath = "bin/esbuild";
        isWASM = true;
      } else {
        throw new Error(`Unsupported platform: ${platformKey}`);
      }
      return { pkg, subpath, isWASM };
    }
    function pkgForSomeOtherPlatform() {
      const libMainJS = require.resolve("esbuild");
      const nodeModulesDirectory = path.dirname(path.dirname(path.dirname(libMainJS)));
      if (path.basename(nodeModulesDirectory) === "node_modules") {
        for (const unixKey in knownUnixlikePackages) {
          try {
            const pkg = knownUnixlikePackages[unixKey];
            if (fs.existsSync(path.join(nodeModulesDirectory, pkg)))
              return pkg;
          } catch {
          }
        }
        for (const windowsKey in knownWindowsPackages) {
          try {
            const pkg = knownWindowsPackages[windowsKey];
            if (fs.existsSync(path.join(nodeModulesDirectory, pkg)))
              return pkg;
          } catch {
          }
        }
      }
      return null;
    }
    function downloadedBinPath(pkg, subpath) {
      const esbuildLibDir = path.dirname(require.resolve("esbuild"));
      return path.join(esbuildLibDir, `downloaded-${pkg}-${path.basename(subpath)}`);
    }
    function generateBinPath() {
      if (ESBUILD_BINARY_PATH) {
        return { binPath: ESBUILD_BINARY_PATH, isWASM: false };
      }
      const { pkg, subpath, isWASM } = pkgAndSubpathForCurrentPlatform();
      let binPath;
      try {
        binPath = require.resolve(`${pkg}/${subpath}`);
      } catch (e) {
        binPath = downloadedBinPath(pkg, subpath);
        if (!fs.existsSync(binPath)) {
          try {
            require.resolve(pkg);
          } catch {
            const otherPkg = pkgForSomeOtherPlatform();
            if (otherPkg) {
              let suggestions = `
Specifically the "${otherPkg}" package is present but this platform
needs the "${pkg}" package instead. People often get into this
situation by installing esbuild on Windows or macOS and copying "node_modules"
into a Docker image that runs Linux, or by copying "node_modules" between
Windows and WSL environments.

If you are installing with npm, you can try not copying the "node_modules"
directory when you copy the files over, and running "npm ci" or "npm install"
on the destination platform after the copy. Or you could consider using yarn
instead of npm which has built-in support for installing a package on multiple
platforms simultaneously.

If you are installing with yarn, you can try listing both this platform and the
other platform in your ".yarnrc.yml" file using the "supportedArchitectures"
feature: https://yarnpkg.com/configuration/yarnrc/#supportedArchitectures
Keep in mind that this means multiple copies of esbuild will be present.
`;
              if (pkg === packageDarwin_x64 && otherPkg === packageDarwin_arm64 || pkg === packageDarwin_arm64 && otherPkg === packageDarwin_x64) {
                suggestions = `
Specifically the "${otherPkg}" package is present but this platform
needs the "${pkg}" package instead. People often get into this
situation by installing esbuild with npm running inside of Rosetta 2 and then
trying to use it with node running outside of Rosetta 2, or vice versa (Rosetta
2 is Apple's on-the-fly x86_64-to-arm64 translation service).

If you are installing with npm, you can try ensuring that both npm and node are
not running under Rosetta 2 and then reinstalling esbuild. This likely involves
changing how you installed npm and/or node. For example, installing node with
the universal installer here should work: https://nodejs.org/en/download/. Or
you could consider using yarn instead of npm which has built-in support for
installing a package on multiple platforms simultaneously.

If you are installing with yarn, you can try listing both "arm64" and "x64"
in your ".yarnrc.yml" file using the "supportedArchitectures" feature:
https://yarnpkg.com/configuration/yarnrc/#supportedArchitectures
Keep in mind that this means multiple copies of esbuild will be present.
`;
              }
              throw new Error(`
You installed esbuild for another platform than the one you're currently using.
This won't work because esbuild is written with native code and needs to
install a platform-specific binary executable.
${suggestions}
Another alternative is to use the "esbuild-wasm" package instead, which works
the same way on all platforms. But it comes with a heavy performance cost and
can sometimes be 10x slower than the "esbuild" package, so you may also not
want to do that.
`);
            }
            throw new Error(`The package "${pkg}" could not be found, and is needed by esbuild.

If you are installing esbuild with npm, make sure that you don't specify the
"--no-optional" or "--omit=optional" flags. The "optionalDependencies" feature
of "package.json" is used by esbuild to install the correct binary executable
for your current platform.`);
          }
          throw e;
        }
      }
      if (/\.zip\//.test(binPath)) {
        let pnpapi;
        try {
          pnpapi = require("pnpapi");
        } catch (e) {
        }
        if (pnpapi) {
          const root = pnpapi.getPackageInformation(pnpapi.topLevel).packageLocation;
          const binTargetPath = path.join(root, "node_modules", ".cache", "esbuild", `pnpapi-${pkg}-${"0.15.18"}-${path.basename(subpath)}`);
          if (!fs.existsSync(binTargetPath)) {
            fs.mkdirSync(path.dirname(binTargetPath), { recursive: true });
            fs.copyFileSync(binPath, binTargetPath);
            fs.chmodSync(binTargetPath, 493);
          }
          return { binPath: binTargetPath, isWASM };
        }
      }
      return { binPath, isWASM };
    }
    var child_process = require("child_process");
    var crypto = require("crypto");
    var path2 = require("path");
    var fs2 = require("fs");
    var os2 = require("os");
    var tty = require("tty");
    var worker_threads;
    if (process.env.ESBUILD_WORKER_THREADS !== "0") {
      try {
        worker_threads = require("worker_threads");
      } catch {
      }
      let [major, minor] = process.versions.node.split(".");
      if (+major < 12 || +major === 12 && +minor < 17 || +major === 13 && +minor < 13) {
        worker_threads = void 0;
      }
    }
    var _a;
    var isInternalWorkerThread = ((_a = worker_threads == null ? void 0 : worker_threads.workerData) == null ? void 0 : _a.esbuildVersion) === "0.15.18";
    var esbuildCommandAndArgs = () => {
      if ((!ESBUILD_BINARY_PATH || false) && (path2.basename(__filename) !== "main.js" || path2.basename(__dirname) !== "lib")) {
        throw new Error(`The esbuild JavaScript API cannot be bundled. Please mark the "esbuild" package as external so it's not included in the bundle.

More information: The file containing the code for esbuild's JavaScript API (${__filename}) does not appear to be inside the esbuild package on the file system, which usually means that the esbuild package was bundled into another file. This is problematic because the API needs to run a binary executable inside the esbuild package which is located using a relative path from the API code to the executable. If the esbuild package is bundled, the relative path will be incorrect and the executable won't be found.`);
      }
      if (false) {
        return ["node", [path2.join(__dirname, "..", "bin", "esbuild")]];
      } else {
        const { binPath, isWASM } = generateBinPath();
        if (isWASM) {
          return ["node", [binPath]];
        } else {
          return [binPath, []];
        }
      }
    };
    var isTTY = () => tty.isatty(2);
    var fsSync = {
      readFile(tempFile, callback) {
        try {
          let contents = fs2.readFileSync(tempFile, "utf8");
          try {
            fs2.unlinkSync(tempFile);
          } catch {
          }
          callback(null, contents);
        } catch (err) {
          callback(err, null);
        }
      },
      writeFile(contents, callback) {
        try {
          let tempFile = randomFileName();
          fs2.writeFileSync(tempFile, contents);
          callback(tempFile);
        } catch {
          callback(null);
        }
      }
    };
    var fsAsync = {
      readFile(tempFile, callback) {
        try {
          fs2.readFile(tempFile, "utf8", (err, contents) => {
            try {
              fs2.unlink(tempFile, () => callback(err, contents));
            } catch {
              callback(err, contents);
            }
          });
        } catch (err) {
          callback(err, null);
        }
      },
      writeFile(contents, callback) {
        try {
          let tempFile = randomFileName();
          fs2.writeFile(tempFile, contents, (err) => err !== null ? callback(null) : callback(tempFile));
        } catch {
          callback(null);
        }
      }
    };
    var version = "0.15.18";
    var build = (options) => ensureServiceIsRunning().build(options);
    var serve = (serveOptions, buildOptions) => ensureServiceIsRunning().serve(serveOptions, buildOptions);
    var transform = (input, options) => ensureServiceIsRunning().transform(input, options);
    var formatMessages = (messages, options) => ensureServiceIsRunning().formatMessages(messages, options);
    var analyzeMetafile = (messages, options) => ensureServiceIsRunning().analyzeMetafile(messages, options);
    var buildSync = (options) => {
      if (worker_threads && !isInternalWorkerThread) {
        if (!workerThreadService)
          workerThreadService = startWorkerThreadService(worker_threads);
        return workerThreadService.buildSync(options);
      }
      let result;
      runServiceSync((service) => service.buildOrServe({
        callName: "buildSync",
        refs: null,
        serveOptions: null,
        options,
        isTTY: isTTY(),
        defaultWD,
        callback: (err, res) => {
          if (err)
            throw err;
          result = res;
        }
      }));
      return result;
    };
    var transformSync = (input, options) => {
      if (worker_threads && !isInternalWorkerThread) {
        if (!workerThreadService)
          workerThreadService = startWorkerThreadService(worker_threads);
        return workerThreadService.transformSync(input, options);
      }
      let result;
      runServiceSync((service) => service.transform({
        callName: "transformSync",
        refs: null,
        input,
        options: options || {},
        isTTY: isTTY(),
        fs: fsSync,
        callback: (err, res) => {
          if (err)
            throw err;
          result = res;
        }
      }));
      return result;
    };
    var formatMessagesSync = (messages, options) => {
      if (worker_threads && !isInternalWorkerThread) {
        if (!workerThreadService)
          workerThreadService = startWorkerThreadService(worker_threads);
        return workerThreadService.formatMessagesSync(messages, options);
      }
      let result;
      runServiceSync((service) => service.formatMessages({
        callName: "formatMessagesSync",
        refs: null,
        messages,
        options,
        callback: (err, res) => {
          if (err)
            throw err;
          result = res;
        }
      }));
      return result;
    };
    var analyzeMetafileSync = (metafile, options) => {
      if (worker_threads && !isInternalWorkerThread) {
        if (!workerThreadService)
          workerThreadService = startWorkerThreadService(worker_threads);
        return workerThreadService.analyzeMetafileSync(metafile, options);
      }
      let result;
      runServiceSync((service) => service.analyzeMetafile({
        callName: "analyzeMetafileSync",
        refs: null,
        metafile: typeof metafile === "string" ? metafile : JSON.stringify(metafile),
        options,
        callback: (err, res) => {
          if (err)
            throw err;
          result = res;
        }
      }));
      return result;
    };
    var initializeWasCalled = false;
    var initialize = (options) => {
      options = validateInitializeOptions(options || {});
      if (options.wasmURL)
        throw new Error(`The "wasmURL" option only works in the browser`);
      if (options.wasmModule)
        throw new Error(`The "wasmModule" option only works in the browser`);
      if (options.worker)
        throw new Error(`The "worker" option only works in the browser`);
      if (initializeWasCalled)
        throw new Error('Cannot call "initialize" more than once');
      ensureServiceIsRunning();
      initializeWasCalled = true;
      return Promise.resolve();
    };
    var defaultWD = process.cwd();
    var longLivedService;
    var ensureServiceIsRunning = () => {
      if (longLivedService)
        return longLivedService;
      let [command, args] = esbuildCommandAndArgs();
      let child = child_process.spawn(command, args.concat(`--service=${"0.15.18"}`, "--ping"), {
        windowsHide: true,
        stdio: ["pipe", "pipe", "inherit"],
        cwd: defaultWD
      });
      let { readFromStdout, afterClose, service } = createChannel({
        writeToStdin(bytes) {
          child.stdin.write(bytes, (err) => {
            if (err)
              afterClose(err);
          });
        },
        readFileSync: fs2.readFileSync,
        isSync: false,
        isWriteUnavailable: false,
        esbuild: node_exports
      });
      child.stdin.on("error", afterClose);
      child.on("error", afterClose);
      const stdin = child.stdin;
      const stdout = child.stdout;
      stdout.on("data", readFromStdout);
      stdout.on("end", afterClose);
      let refCount = 0;
      child.unref();
      if (stdin.unref) {
        stdin.unref();
      }
      if (stdout.unref) {
        stdout.unref();
      }
      const refs = {
        ref() {
          if (++refCount === 1)
            child.ref();
        },
        unref() {
          if (--refCount === 0)
            child.unref();
        }
      };
      longLivedService = {
        build: (options) => {
          return new Promise((resolve, reject) => {
            service.buildOrServe({
              callName: "build",
              refs,
              serveOptions: null,
              options,
              isTTY: isTTY(),
              defaultWD,
              callback: (err, res) => err ? reject(err) : resolve(res)
            });
          });
        },
        serve: (serveOptions, buildOptions) => {
          if (serveOptions === null || typeof serveOptions !== "object")
            throw new Error("The first argument must be an object");
          return new Promise((resolve, reject) => service.buildOrServe({
            callName: "serve",
            refs,
            serveOptions,
            options: buildOptions,
            isTTY: isTTY(),
            defaultWD,
            callback: (err, res) => err ? reject(err) : resolve(res)
          }));
        },
        transform: (input, options) => {
          return new Promise((resolve, reject) => service.transform({
            callName: "transform",
            refs,
            input,
            options: options || {},
            isTTY: isTTY(),
            fs: fsAsync,
            callback: (err, res) => err ? reject(err) : resolve(res)
          }));
        },
        formatMessages: (messages, options) => {
          return new Promise((resolve, reject) => service.formatMessages({
            callName: "formatMessages",
            refs,
            messages,
            options,
            callback: (err, res) => err ? reject(err) : resolve(res)
          }));
        },
        analyzeMetafile: (metafile, options) => {
          return new Promise((resolve, reject) => service.analyzeMetafile({
            callName: "analyzeMetafile",
            refs,
            metafile: typeof metafile === "string" ? metafile : JSON.stringify(metafile),
            options,
            callback: (err, res) => err ? reject(err) : resolve(res)
          }));
        }
      };
      return longLivedService;
    };
    var runServiceSync = (callback) => {
      let [command, args] = esbuildCommandAndArgs();
      let stdin = new Uint8Array();
      let { readFromStdout, afterClose, service } = createChannel({
        writeToStdin(bytes) {
          if (stdin.length !== 0)
            throw new Error("Must run at most one command");
          stdin = bytes;
        },
        isSync: true,
        isWriteUnavailable: false,
        esbuild: node_exports
      });
      callback(service);
      let stdout = child_process.execFileSync(command, args.concat(`--service=${"0.15.18"}`), {
        cwd: defaultWD,
        windowsHide: true,
        input: stdin,
        maxBuffer: +process.env.ESBUILD_MAX_BUFFER || 16 * 1024 * 1024
      });
      readFromStdout(stdout);
      afterClose(null);
    };
    var randomFileName = () => {
      return path2.join(os2.tmpdir(), `esbuild-${crypto.randomBytes(32).toString("hex")}`);
    };
    var workerThreadService = null;
    var startWorkerThreadService = (worker_threads2) => {
      let { port1: mainPort, port2: workerPort } = new worker_threads2.MessageChannel();
      let worker = new worker_threads2.Worker(__filename, {
        workerData: { workerPort, defaultWD, esbuildVersion: "0.15.18" },
        transferList: [workerPort],
        execArgv: []
      });
      let nextID = 0;
      let fakeBuildError = (text) => {
        let error = new Error(`Build failed with 1 error:
error: ${text}`);
        let errors = [{ id: "", pluginName: "", text, location: null, notes: [], detail: void 0 }];
        error.errors = errors;
        error.warnings = [];
        return error;
      };
      let validateBuildSyncOptions = (options) => {
        if (!options)
          return;
        let plugins = options.plugins;
        let incremental = options.incremental;
        let watch = options.watch;
        if (plugins && plugins.length > 0)
          throw fakeBuildError(`Cannot use plugins in synchronous API calls`);
        if (incremental)
          throw fakeBuildError(`Cannot use "incremental" with a synchronous build`);
        if (watch)
          throw fakeBuildError(`Cannot use "watch" with a synchronous build`);
      };
      let applyProperties = (object, properties) => {
        for (let key in properties) {
          object[key] = properties[key];
        }
      };
      let runCallSync = (command, args) => {
        let id = nextID++;
        let sharedBuffer = new SharedArrayBuffer(8);
        let sharedBufferView = new Int32Array(sharedBuffer);
        let msg = { sharedBuffer, id, command, args };
        worker.postMessage(msg);
        let status = Atomics.wait(sharedBufferView, 0, 0);
        if (status !== "ok" && status !== "not-equal")
          throw new Error("Internal error: Atomics.wait() failed: " + status);
        let { message: { id: id2, resolve, reject, properties } } = worker_threads2.receiveMessageOnPort(mainPort);
        if (id !== id2)
          throw new Error(`Internal error: Expected id ${id} but got id ${id2}`);
        if (reject) {
          applyProperties(reject, properties);
          throw reject;
        }
        return resolve;
      };
      worker.unref();
      return {
        buildSync(options) {
          validateBuildSyncOptions(options);
          return runCallSync("build", [options]);
        },
        transformSync(input, options) {
          return runCallSync("transform", [input, options]);
        },
        formatMessagesSync(messages, options) {
          return runCallSync("formatMessages", [messages, options]);
        },
        analyzeMetafileSync(metafile, options) {
          return runCallSync("analyzeMetafile", [metafile, options]);
        }
      };
    };
    var startSyncServiceWorker = () => {
      let workerPort = worker_threads.workerData.workerPort;
      let parentPort = worker_threads.parentPort;
      let extractProperties = (object) => {
        let properties = {};
        if (object && typeof object === "object") {
          for (let key in object) {
            properties[key] = object[key];
          }
        }
        return properties;
      };
      try {
        let service = ensureServiceIsRunning();
        defaultWD = worker_threads.workerData.defaultWD;
        parentPort.on("message", (msg) => {
          (async () => {
            let { sharedBuffer, id, command, args } = msg;
            let sharedBufferView = new Int32Array(sharedBuffer);
            try {
              switch (command) {
                case "build":
                  workerPort.postMessage({ id, resolve: await service.build(args[0]) });
                  break;
                case "transform":
                  workerPort.postMessage({ id, resolve: await service.transform(args[0], args[1]) });
                  break;
                case "formatMessages":
                  workerPort.postMessage({ id, resolve: await service.formatMessages(args[0], args[1]) });
                  break;
                case "analyzeMetafile":
                  workerPort.postMessage({ id, resolve: await service.analyzeMetafile(args[0], args[1]) });
                  break;
                default:
                  throw new Error(`Invalid command: ${command}`);
              }
            } catch (reject) {
              workerPort.postMessage({ id, reject, properties: extractProperties(reject) });
            }
            Atomics.add(sharedBufferView, 0, 1);
            Atomics.notify(sharedBufferView, 0, Infinity);
          })();
        });
      } catch (reject) {
        parentPort.on("message", (msg) => {
          let { sharedBuffer, id } = msg;
          let sharedBufferView = new Int32Array(sharedBuffer);
          workerPort.postMessage({ id, reject, properties: extractProperties(reject) });
          Atomics.add(sharedBufferView, 0, 1);
          Atomics.notify(sharedBufferView, 0, Infinity);
        });
      }
    };
    if (isInternalWorkerThread) {
      startSyncServiceWorker();
    }
    var node_default = node_exports;
  }
});

// node_modules/path-is-absolute/index.js
var require_path_is_absolute = __commonJS({
  "node_modules/path-is-absolute/index.js"(exports, module2) {
    "use strict";
    function posix(path) {
      return path.charAt(0) === "/";
    }
    function win32(path) {
      var splitDeviceRe = /^([a-zA-Z]:|[\\\/]{2}[^\\\/]+[\\\/]+[^\\\/]+)?([\\\/])?([\s\S]*?)$/;
      var result = splitDeviceRe.exec(path);
      var device = result[1] || "";
      var isUnc = Boolean(device && device.charAt(1) !== ":");
      return Boolean(result[2] || isUnc);
    }
    module2.exports = process.platform === "win32" ? win32 : posix;
    module2.exports.posix = posix;
    module2.exports.win32 = win32;
  }
});

// node_modules/node-eval/index.js
var require_node_eval = __commonJS({
  "node_modules/node-eval/index.js"(exports, module2) {
    "use strict";
    var vm = require("vm");
    var path = require("path");
    var Module = require("module");
    var isAbsolutePath = require_path_is_absolute();
    module2.exports = (content, filename, context) => {
      const ext = filename && path.extname(filename);
      content = stripBOM(content);
      if (ext === ".json") {
        return tryCatch(JSON.parse.bind(null, content), (err) => {
          err.message = `${filename}: ${err.message}`;
          throw err;
        });
      }
      if (filename && !isAbsolutePath(filename)) {
        filename = path.resolve(path.dirname(_getCalleeFilename()), filename);
      }
      let sandbox;
      if (/\b(exports|module)\b/.test(content)) {
        sandbox = _commonjsEval(content, filename, context);
      }
      let result;
      if (sandbox && !sandbox.__result) {
        result = sandbox.module.exports;
      } else {
        result = context ? vm.runInNewContext(content, context) : vm.runInThisContext(content);
      }
      return result;
    };
    function _commonjsEval(content, filename, context) {
      const dirname = filename && path.dirname(filename);
      const sandbox = {};
      const exports2 = {};
      let contextKeys;
      sandbox.module = new Module(filename || "<anonymous>", module2.parent);
      sandbox.module.exports = exports2;
      if (filename) {
        sandbox.module.filename = filename;
        sandbox.module.paths = Module._nodeModulePaths(dirname);
        sandbox.require = (id) => sandbox.module.require(id);
        sandbox.require.resolve = (req) => Module._resolveFilename(req, sandbox.module);
      } else {
        filename = "<anonymous>";
        sandbox.require = filenameRequired;
      }
      const args = [sandbox.module.exports, sandbox.require, sandbox.module, filename, dirname];
      context && (contextKeys = Object.keys(context).map((key) => {
        args.push(context[key]);
        return key;
      }));
      const wrapper = wrap(content, contextKeys);
      const options = { filename, lineOffset: 0, displayErrors: true };
      const compiledWrapper = vm.runInThisContext(wrapper, options);
      const moduleKeysCount = Object.keys(sandbox.module).length;
      const exportKeysCount = Object.keys(sandbox.module.exports).length;
      compiledWrapper.apply(sandbox.module.exports, args);
      sandbox.__result = sandbox.module.exports === exports2 && Object.keys(sandbox.module.exports).length === exportKeysCount && Object.keys(sandbox.module).length === moduleKeysCount;
      return sandbox;
    }
    function wrap(body, extKeys) {
      const wrapper = [
        "(function (exports, require, module, __filename, __dirname",
        ") { ",
        "\n});"
      ];
      extKeys = extKeys ? `, ${extKeys}` : "";
      return wrapper[0] + extKeys + wrapper[1] + body + wrapper[2];
    }
    function tryCatch(fn, cb) {
      try {
        return fn();
      } catch (e) {
        cb(e);
      }
    }
    function stripBOM(content) {
      if (content.charCodeAt(0) === 65279) {
        content = content.slice(1);
      }
      return content;
    }
    function _getCalleeFilename(calls) {
      calls = (calls | 0) + 3;
      const e = {};
      Error.captureStackTrace(e);
      return parseStackLine(e.stack.split(/\n/)[calls]).filename;
    }
    function parseStackLine(line) {
      const urlLike = line.replace(/^\s+/, "").replace(/\(eval code/g, "(").split(/\s+/).pop();
      const parts = /(.+?)(?::(\d+))?(?::(\d+))?$/.exec(urlLike.replace(/[()]/g, ""));
      const filename = ["eval", "<anonymous>"].indexOf(parts[1]) > -1 ? void 0 : parts[1];
      return { filename, line: parts[2], column: parts[3] };
    }
    function filenameRequired() {
      throw new Error("Please pass in filename to use require");
    }
    filenameRequired.resolve = filenameRequired;
  }
});

// node_modules/http-status-codes/build/cjs/legacy.js
var require_legacy = __commonJS({
  "node_modules/http-status-codes/build/cjs/legacy.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.USE_PROXY = exports.UNSUPPORTED_MEDIA_TYPE = exports.UNPROCESSABLE_ENTITY = exports.UNAUTHORIZED = exports.TOO_MANY_REQUESTS = exports.TEMPORARY_REDIRECT = exports.SWITCHING_PROTOCOLS = exports.SERVICE_UNAVAILABLE = exports.SEE_OTHER = exports.RESET_CONTENT = exports.REQUESTED_RANGE_NOT_SATISFIABLE = exports.REQUEST_URI_TOO_LONG = exports.REQUEST_TOO_LONG = exports.REQUEST_TIMEOUT = exports.REQUEST_HEADER_FIELDS_TOO_LARGE = exports.PROXY_AUTHENTICATION_REQUIRED = exports.PROCESSING = exports.PRECONDITION_REQUIRED = exports.PRECONDITION_FAILED = exports.PERMANENT_REDIRECT = exports.PAYMENT_REQUIRED = exports.PARTIAL_CONTENT = exports.OK = exports.NOT_MODIFIED = exports.NOT_IMPLEMENTED = exports.NOT_FOUND = exports.NOT_ACCEPTABLE = exports.NON_AUTHORITATIVE_INFORMATION = exports.NO_CONTENT = exports.NETWORK_AUTHENTICATION_REQUIRED = exports.MULTIPLE_CHOICES = exports.MULTI_STATUS = exports.MOVED_TEMPORARILY = exports.MOVED_PERMANENTLY = exports.METHOD_NOT_ALLOWED = exports.METHOD_FAILURE = exports.LOCKED = exports.LENGTH_REQUIRED = exports.INTERNAL_SERVER_ERROR = exports.INSUFFICIENT_STORAGE = exports.INSUFFICIENT_SPACE_ON_RESOURCE = exports.IM_A_TEAPOT = exports.HTTP_VERSION_NOT_SUPPORTED = exports.GONE = exports.GATEWAY_TIMEOUT = exports.FORBIDDEN = exports.FAILED_DEPENDENCY = exports.EXPECTATION_FAILED = exports.CREATED = exports.CONTINUE = exports.CONFLICT = exports.BAD_REQUEST = exports.BAD_GATEWAY = exports.ACCEPTED = void 0;
    exports.ACCEPTED = 202;
    exports.BAD_GATEWAY = 502;
    exports.BAD_REQUEST = 400;
    exports.CONFLICT = 409;
    exports.CONTINUE = 100;
    exports.CREATED = 201;
    exports.EXPECTATION_FAILED = 417;
    exports.FAILED_DEPENDENCY = 424;
    exports.FORBIDDEN = 403;
    exports.GATEWAY_TIMEOUT = 504;
    exports.GONE = 410;
    exports.HTTP_VERSION_NOT_SUPPORTED = 505;
    exports.IM_A_TEAPOT = 418;
    exports.INSUFFICIENT_SPACE_ON_RESOURCE = 419;
    exports.INSUFFICIENT_STORAGE = 507;
    exports.INTERNAL_SERVER_ERROR = 500;
    exports.LENGTH_REQUIRED = 411;
    exports.LOCKED = 423;
    exports.METHOD_FAILURE = 420;
    exports.METHOD_NOT_ALLOWED = 405;
    exports.MOVED_PERMANENTLY = 301;
    exports.MOVED_TEMPORARILY = 302;
    exports.MULTI_STATUS = 207;
    exports.MULTIPLE_CHOICES = 300;
    exports.NETWORK_AUTHENTICATION_REQUIRED = 511;
    exports.NO_CONTENT = 204;
    exports.NON_AUTHORITATIVE_INFORMATION = 203;
    exports.NOT_ACCEPTABLE = 406;
    exports.NOT_FOUND = 404;
    exports.NOT_IMPLEMENTED = 501;
    exports.NOT_MODIFIED = 304;
    exports.OK = 200;
    exports.PARTIAL_CONTENT = 206;
    exports.PAYMENT_REQUIRED = 402;
    exports.PERMANENT_REDIRECT = 308;
    exports.PRECONDITION_FAILED = 412;
    exports.PRECONDITION_REQUIRED = 428;
    exports.PROCESSING = 102;
    exports.PROXY_AUTHENTICATION_REQUIRED = 407;
    exports.REQUEST_HEADER_FIELDS_TOO_LARGE = 431;
    exports.REQUEST_TIMEOUT = 408;
    exports.REQUEST_TOO_LONG = 413;
    exports.REQUEST_URI_TOO_LONG = 414;
    exports.REQUESTED_RANGE_NOT_SATISFIABLE = 416;
    exports.RESET_CONTENT = 205;
    exports.SEE_OTHER = 303;
    exports.SERVICE_UNAVAILABLE = 503;
    exports.SWITCHING_PROTOCOLS = 101;
    exports.TEMPORARY_REDIRECT = 307;
    exports.TOO_MANY_REQUESTS = 429;
    exports.UNAUTHORIZED = 401;
    exports.UNPROCESSABLE_ENTITY = 422;
    exports.UNSUPPORTED_MEDIA_TYPE = 415;
    exports.USE_PROXY = 305;
    exports.default = {
      ACCEPTED: exports.ACCEPTED,
      BAD_GATEWAY: exports.BAD_GATEWAY,
      BAD_REQUEST: exports.BAD_REQUEST,
      CONFLICT: exports.CONFLICT,
      CONTINUE: exports.CONTINUE,
      CREATED: exports.CREATED,
      EXPECTATION_FAILED: exports.EXPECTATION_FAILED,
      FORBIDDEN: exports.FORBIDDEN,
      GATEWAY_TIMEOUT: exports.GATEWAY_TIMEOUT,
      GONE: exports.GONE,
      HTTP_VERSION_NOT_SUPPORTED: exports.HTTP_VERSION_NOT_SUPPORTED,
      IM_A_TEAPOT: exports.IM_A_TEAPOT,
      INSUFFICIENT_SPACE_ON_RESOURCE: exports.INSUFFICIENT_SPACE_ON_RESOURCE,
      INSUFFICIENT_STORAGE: exports.INSUFFICIENT_STORAGE,
      INTERNAL_SERVER_ERROR: exports.INTERNAL_SERVER_ERROR,
      LENGTH_REQUIRED: exports.LENGTH_REQUIRED,
      LOCKED: exports.LOCKED,
      METHOD_FAILURE: exports.METHOD_FAILURE,
      METHOD_NOT_ALLOWED: exports.METHOD_NOT_ALLOWED,
      MOVED_PERMANENTLY: exports.MOVED_PERMANENTLY,
      MOVED_TEMPORARILY: exports.MOVED_TEMPORARILY,
      MULTI_STATUS: exports.MULTI_STATUS,
      MULTIPLE_CHOICES: exports.MULTIPLE_CHOICES,
      NETWORK_AUTHENTICATION_REQUIRED: exports.NETWORK_AUTHENTICATION_REQUIRED,
      NO_CONTENT: exports.NO_CONTENT,
      NON_AUTHORITATIVE_INFORMATION: exports.NON_AUTHORITATIVE_INFORMATION,
      NOT_ACCEPTABLE: exports.NOT_ACCEPTABLE,
      NOT_FOUND: exports.NOT_FOUND,
      NOT_IMPLEMENTED: exports.NOT_IMPLEMENTED,
      NOT_MODIFIED: exports.NOT_MODIFIED,
      OK: exports.OK,
      PARTIAL_CONTENT: exports.PARTIAL_CONTENT,
      PAYMENT_REQUIRED: exports.PAYMENT_REQUIRED,
      PERMANENT_REDIRECT: exports.PERMANENT_REDIRECT,
      PRECONDITION_FAILED: exports.PRECONDITION_FAILED,
      PRECONDITION_REQUIRED: exports.PRECONDITION_REQUIRED,
      PROCESSING: exports.PROCESSING,
      PROXY_AUTHENTICATION_REQUIRED: exports.PROXY_AUTHENTICATION_REQUIRED,
      REQUEST_HEADER_FIELDS_TOO_LARGE: exports.REQUEST_HEADER_FIELDS_TOO_LARGE,
      REQUEST_TIMEOUT: exports.REQUEST_TIMEOUT,
      REQUEST_TOO_LONG: exports.REQUEST_TOO_LONG,
      REQUEST_URI_TOO_LONG: exports.REQUEST_URI_TOO_LONG,
      REQUESTED_RANGE_NOT_SATISFIABLE: exports.REQUESTED_RANGE_NOT_SATISFIABLE,
      RESET_CONTENT: exports.RESET_CONTENT,
      SEE_OTHER: exports.SEE_OTHER,
      SERVICE_UNAVAILABLE: exports.SERVICE_UNAVAILABLE,
      SWITCHING_PROTOCOLS: exports.SWITCHING_PROTOCOLS,
      TEMPORARY_REDIRECT: exports.TEMPORARY_REDIRECT,
      TOO_MANY_REQUESTS: exports.TOO_MANY_REQUESTS,
      UNAUTHORIZED: exports.UNAUTHORIZED,
      UNPROCESSABLE_ENTITY: exports.UNPROCESSABLE_ENTITY,
      UNSUPPORTED_MEDIA_TYPE: exports.UNSUPPORTED_MEDIA_TYPE,
      USE_PROXY: exports.USE_PROXY
    };
  }
});

// node_modules/http-status-codes/build/cjs/utils.js
var require_utils = __commonJS({
  "node_modules/http-status-codes/build/cjs/utils.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.reasonPhraseToStatusCode = exports.statusCodeToReasonPhrase = void 0;
    exports.statusCodeToReasonPhrase = {
      "202": "Accepted",
      "502": "Bad Gateway",
      "400": "Bad Request",
      "409": "Conflict",
      "100": "Continue",
      "201": "Created",
      "417": "Expectation Failed",
      "424": "Failed Dependency",
      "403": "Forbidden",
      "504": "Gateway Timeout",
      "410": "Gone",
      "505": "HTTP Version Not Supported",
      "418": "I'm a teapot",
      "419": "Insufficient Space on Resource",
      "507": "Insufficient Storage",
      "500": "Internal Server Error",
      "411": "Length Required",
      "423": "Locked",
      "420": "Method Failure",
      "405": "Method Not Allowed",
      "301": "Moved Permanently",
      "302": "Moved Temporarily",
      "207": "Multi-Status",
      "300": "Multiple Choices",
      "511": "Network Authentication Required",
      "204": "No Content",
      "203": "Non Authoritative Information",
      "406": "Not Acceptable",
      "404": "Not Found",
      "501": "Not Implemented",
      "304": "Not Modified",
      "200": "OK",
      "206": "Partial Content",
      "402": "Payment Required",
      "308": "Permanent Redirect",
      "412": "Precondition Failed",
      "428": "Precondition Required",
      "102": "Processing",
      "407": "Proxy Authentication Required",
      "431": "Request Header Fields Too Large",
      "408": "Request Timeout",
      "413": "Request Entity Too Large",
      "414": "Request-URI Too Long",
      "416": "Requested Range Not Satisfiable",
      "205": "Reset Content",
      "303": "See Other",
      "503": "Service Unavailable",
      "101": "Switching Protocols",
      "307": "Temporary Redirect",
      "429": "Too Many Requests",
      "401": "Unauthorized",
      "451": "Unavailable For Legal Reasons",
      "422": "Unprocessable Entity",
      "415": "Unsupported Media Type",
      "305": "Use Proxy",
      "421": "Misdirected Request"
    };
    exports.reasonPhraseToStatusCode = {
      "Accepted": 202,
      "Bad Gateway": 502,
      "Bad Request": 400,
      "Conflict": 409,
      "Continue": 100,
      "Created": 201,
      "Expectation Failed": 417,
      "Failed Dependency": 424,
      "Forbidden": 403,
      "Gateway Timeout": 504,
      "Gone": 410,
      "HTTP Version Not Supported": 505,
      "I'm a teapot": 418,
      "Insufficient Space on Resource": 419,
      "Insufficient Storage": 507,
      "Internal Server Error": 500,
      "Length Required": 411,
      "Locked": 423,
      "Method Failure": 420,
      "Method Not Allowed": 405,
      "Moved Permanently": 301,
      "Moved Temporarily": 302,
      "Multi-Status": 207,
      "Multiple Choices": 300,
      "Network Authentication Required": 511,
      "No Content": 204,
      "Non Authoritative Information": 203,
      "Not Acceptable": 406,
      "Not Found": 404,
      "Not Implemented": 501,
      "Not Modified": 304,
      "OK": 200,
      "Partial Content": 206,
      "Payment Required": 402,
      "Permanent Redirect": 308,
      "Precondition Failed": 412,
      "Precondition Required": 428,
      "Processing": 102,
      "Proxy Authentication Required": 407,
      "Request Header Fields Too Large": 431,
      "Request Timeout": 408,
      "Request Entity Too Large": 413,
      "Request-URI Too Long": 414,
      "Requested Range Not Satisfiable": 416,
      "Reset Content": 205,
      "See Other": 303,
      "Service Unavailable": 503,
      "Switching Protocols": 101,
      "Temporary Redirect": 307,
      "Too Many Requests": 429,
      "Unauthorized": 401,
      "Unavailable For Legal Reasons": 451,
      "Unprocessable Entity": 422,
      "Unsupported Media Type": 415,
      "Use Proxy": 305,
      "Misdirected Request": 421
    };
  }
});

// node_modules/http-status-codes/build/cjs/utils-functions.js
var require_utils_functions = __commonJS({
  "node_modules/http-status-codes/build/cjs/utils-functions.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.getStatusText = exports.getStatusCode = exports.getReasonPhrase = void 0;
    var utils_1 = require_utils();
    function getReasonPhrase(statusCode) {
      var result = utils_1.statusCodeToReasonPhrase[statusCode.toString()];
      if (!result) {
        throw new Error("Status code does not exist: " + statusCode);
      }
      return result;
    }
    exports.getReasonPhrase = getReasonPhrase;
    function getStatusCode(reasonPhrase) {
      var result = utils_1.reasonPhraseToStatusCode[reasonPhrase];
      if (!result) {
        throw new Error("Reason phrase does not exist: " + reasonPhrase);
      }
      return result;
    }
    exports.getStatusCode = getStatusCode;
    exports.getStatusText = getReasonPhrase;
  }
});

// node_modules/http-status-codes/build/cjs/status-codes.js
var require_status_codes = __commonJS({
  "node_modules/http-status-codes/build/cjs/status-codes.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.StatusCodes = void 0;
    var StatusCodes2;
    (function(StatusCodes3) {
      StatusCodes3[StatusCodes3["ACCEPTED"] = 202] = "ACCEPTED";
      StatusCodes3[StatusCodes3["BAD_GATEWAY"] = 502] = "BAD_GATEWAY";
      StatusCodes3[StatusCodes3["BAD_REQUEST"] = 400] = "BAD_REQUEST";
      StatusCodes3[StatusCodes3["CONFLICT"] = 409] = "CONFLICT";
      StatusCodes3[StatusCodes3["CONTINUE"] = 100] = "CONTINUE";
      StatusCodes3[StatusCodes3["CREATED"] = 201] = "CREATED";
      StatusCodes3[StatusCodes3["EXPECTATION_FAILED"] = 417] = "EXPECTATION_FAILED";
      StatusCodes3[StatusCodes3["FAILED_DEPENDENCY"] = 424] = "FAILED_DEPENDENCY";
      StatusCodes3[StatusCodes3["FORBIDDEN"] = 403] = "FORBIDDEN";
      StatusCodes3[StatusCodes3["GATEWAY_TIMEOUT"] = 504] = "GATEWAY_TIMEOUT";
      StatusCodes3[StatusCodes3["GONE"] = 410] = "GONE";
      StatusCodes3[StatusCodes3["HTTP_VERSION_NOT_SUPPORTED"] = 505] = "HTTP_VERSION_NOT_SUPPORTED";
      StatusCodes3[StatusCodes3["IM_A_TEAPOT"] = 418] = "IM_A_TEAPOT";
      StatusCodes3[StatusCodes3["INSUFFICIENT_SPACE_ON_RESOURCE"] = 419] = "INSUFFICIENT_SPACE_ON_RESOURCE";
      StatusCodes3[StatusCodes3["INSUFFICIENT_STORAGE"] = 507] = "INSUFFICIENT_STORAGE";
      StatusCodes3[StatusCodes3["INTERNAL_SERVER_ERROR"] = 500] = "INTERNAL_SERVER_ERROR";
      StatusCodes3[StatusCodes3["LENGTH_REQUIRED"] = 411] = "LENGTH_REQUIRED";
      StatusCodes3[StatusCodes3["LOCKED"] = 423] = "LOCKED";
      StatusCodes3[StatusCodes3["METHOD_FAILURE"] = 420] = "METHOD_FAILURE";
      StatusCodes3[StatusCodes3["METHOD_NOT_ALLOWED"] = 405] = "METHOD_NOT_ALLOWED";
      StatusCodes3[StatusCodes3["MOVED_PERMANENTLY"] = 301] = "MOVED_PERMANENTLY";
      StatusCodes3[StatusCodes3["MOVED_TEMPORARILY"] = 302] = "MOVED_TEMPORARILY";
      StatusCodes3[StatusCodes3["MULTI_STATUS"] = 207] = "MULTI_STATUS";
      StatusCodes3[StatusCodes3["MULTIPLE_CHOICES"] = 300] = "MULTIPLE_CHOICES";
      StatusCodes3[StatusCodes3["NETWORK_AUTHENTICATION_REQUIRED"] = 511] = "NETWORK_AUTHENTICATION_REQUIRED";
      StatusCodes3[StatusCodes3["NO_CONTENT"] = 204] = "NO_CONTENT";
      StatusCodes3[StatusCodes3["NON_AUTHORITATIVE_INFORMATION"] = 203] = "NON_AUTHORITATIVE_INFORMATION";
      StatusCodes3[StatusCodes3["NOT_ACCEPTABLE"] = 406] = "NOT_ACCEPTABLE";
      StatusCodes3[StatusCodes3["NOT_FOUND"] = 404] = "NOT_FOUND";
      StatusCodes3[StatusCodes3["NOT_IMPLEMENTED"] = 501] = "NOT_IMPLEMENTED";
      StatusCodes3[StatusCodes3["NOT_MODIFIED"] = 304] = "NOT_MODIFIED";
      StatusCodes3[StatusCodes3["OK"] = 200] = "OK";
      StatusCodes3[StatusCodes3["PARTIAL_CONTENT"] = 206] = "PARTIAL_CONTENT";
      StatusCodes3[StatusCodes3["PAYMENT_REQUIRED"] = 402] = "PAYMENT_REQUIRED";
      StatusCodes3[StatusCodes3["PERMANENT_REDIRECT"] = 308] = "PERMANENT_REDIRECT";
      StatusCodes3[StatusCodes3["PRECONDITION_FAILED"] = 412] = "PRECONDITION_FAILED";
      StatusCodes3[StatusCodes3["PRECONDITION_REQUIRED"] = 428] = "PRECONDITION_REQUIRED";
      StatusCodes3[StatusCodes3["PROCESSING"] = 102] = "PROCESSING";
      StatusCodes3[StatusCodes3["PROXY_AUTHENTICATION_REQUIRED"] = 407] = "PROXY_AUTHENTICATION_REQUIRED";
      StatusCodes3[StatusCodes3["REQUEST_HEADER_FIELDS_TOO_LARGE"] = 431] = "REQUEST_HEADER_FIELDS_TOO_LARGE";
      StatusCodes3[StatusCodes3["REQUEST_TIMEOUT"] = 408] = "REQUEST_TIMEOUT";
      StatusCodes3[StatusCodes3["REQUEST_TOO_LONG"] = 413] = "REQUEST_TOO_LONG";
      StatusCodes3[StatusCodes3["REQUEST_URI_TOO_LONG"] = 414] = "REQUEST_URI_TOO_LONG";
      StatusCodes3[StatusCodes3["REQUESTED_RANGE_NOT_SATISFIABLE"] = 416] = "REQUESTED_RANGE_NOT_SATISFIABLE";
      StatusCodes3[StatusCodes3["RESET_CONTENT"] = 205] = "RESET_CONTENT";
      StatusCodes3[StatusCodes3["SEE_OTHER"] = 303] = "SEE_OTHER";
      StatusCodes3[StatusCodes3["SERVICE_UNAVAILABLE"] = 503] = "SERVICE_UNAVAILABLE";
      StatusCodes3[StatusCodes3["SWITCHING_PROTOCOLS"] = 101] = "SWITCHING_PROTOCOLS";
      StatusCodes3[StatusCodes3["TEMPORARY_REDIRECT"] = 307] = "TEMPORARY_REDIRECT";
      StatusCodes3[StatusCodes3["TOO_MANY_REQUESTS"] = 429] = "TOO_MANY_REQUESTS";
      StatusCodes3[StatusCodes3["UNAUTHORIZED"] = 401] = "UNAUTHORIZED";
      StatusCodes3[StatusCodes3["UNAVAILABLE_FOR_LEGAL_REASONS"] = 451] = "UNAVAILABLE_FOR_LEGAL_REASONS";
      StatusCodes3[StatusCodes3["UNPROCESSABLE_ENTITY"] = 422] = "UNPROCESSABLE_ENTITY";
      StatusCodes3[StatusCodes3["UNSUPPORTED_MEDIA_TYPE"] = 415] = "UNSUPPORTED_MEDIA_TYPE";
      StatusCodes3[StatusCodes3["USE_PROXY"] = 305] = "USE_PROXY";
      StatusCodes3[StatusCodes3["MISDIRECTED_REQUEST"] = 421] = "MISDIRECTED_REQUEST";
    })(StatusCodes2 = exports.StatusCodes || (exports.StatusCodes = {}));
  }
});

// node_modules/http-status-codes/build/cjs/reason-phrases.js
var require_reason_phrases = __commonJS({
  "node_modules/http-status-codes/build/cjs/reason-phrases.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.ReasonPhrases = void 0;
    var ReasonPhrases;
    (function(ReasonPhrases2) {
      ReasonPhrases2["ACCEPTED"] = "Accepted";
      ReasonPhrases2["BAD_GATEWAY"] = "Bad Gateway";
      ReasonPhrases2["BAD_REQUEST"] = "Bad Request";
      ReasonPhrases2["CONFLICT"] = "Conflict";
      ReasonPhrases2["CONTINUE"] = "Continue";
      ReasonPhrases2["CREATED"] = "Created";
      ReasonPhrases2["EXPECTATION_FAILED"] = "Expectation Failed";
      ReasonPhrases2["FAILED_DEPENDENCY"] = "Failed Dependency";
      ReasonPhrases2["FORBIDDEN"] = "Forbidden";
      ReasonPhrases2["GATEWAY_TIMEOUT"] = "Gateway Timeout";
      ReasonPhrases2["GONE"] = "Gone";
      ReasonPhrases2["HTTP_VERSION_NOT_SUPPORTED"] = "HTTP Version Not Supported";
      ReasonPhrases2["IM_A_TEAPOT"] = "I'm a teapot";
      ReasonPhrases2["INSUFFICIENT_SPACE_ON_RESOURCE"] = "Insufficient Space on Resource";
      ReasonPhrases2["INSUFFICIENT_STORAGE"] = "Insufficient Storage";
      ReasonPhrases2["INTERNAL_SERVER_ERROR"] = "Internal Server Error";
      ReasonPhrases2["LENGTH_REQUIRED"] = "Length Required";
      ReasonPhrases2["LOCKED"] = "Locked";
      ReasonPhrases2["METHOD_FAILURE"] = "Method Failure";
      ReasonPhrases2["METHOD_NOT_ALLOWED"] = "Method Not Allowed";
      ReasonPhrases2["MOVED_PERMANENTLY"] = "Moved Permanently";
      ReasonPhrases2["MOVED_TEMPORARILY"] = "Moved Temporarily";
      ReasonPhrases2["MULTI_STATUS"] = "Multi-Status";
      ReasonPhrases2["MULTIPLE_CHOICES"] = "Multiple Choices";
      ReasonPhrases2["NETWORK_AUTHENTICATION_REQUIRED"] = "Network Authentication Required";
      ReasonPhrases2["NO_CONTENT"] = "No Content";
      ReasonPhrases2["NON_AUTHORITATIVE_INFORMATION"] = "Non Authoritative Information";
      ReasonPhrases2["NOT_ACCEPTABLE"] = "Not Acceptable";
      ReasonPhrases2["NOT_FOUND"] = "Not Found";
      ReasonPhrases2["NOT_IMPLEMENTED"] = "Not Implemented";
      ReasonPhrases2["NOT_MODIFIED"] = "Not Modified";
      ReasonPhrases2["OK"] = "OK";
      ReasonPhrases2["PARTIAL_CONTENT"] = "Partial Content";
      ReasonPhrases2["PAYMENT_REQUIRED"] = "Payment Required";
      ReasonPhrases2["PERMANENT_REDIRECT"] = "Permanent Redirect";
      ReasonPhrases2["PRECONDITION_FAILED"] = "Precondition Failed";
      ReasonPhrases2["PRECONDITION_REQUIRED"] = "Precondition Required";
      ReasonPhrases2["PROCESSING"] = "Processing";
      ReasonPhrases2["PROXY_AUTHENTICATION_REQUIRED"] = "Proxy Authentication Required";
      ReasonPhrases2["REQUEST_HEADER_FIELDS_TOO_LARGE"] = "Request Header Fields Too Large";
      ReasonPhrases2["REQUEST_TIMEOUT"] = "Request Timeout";
      ReasonPhrases2["REQUEST_TOO_LONG"] = "Request Entity Too Large";
      ReasonPhrases2["REQUEST_URI_TOO_LONG"] = "Request-URI Too Long";
      ReasonPhrases2["REQUESTED_RANGE_NOT_SATISFIABLE"] = "Requested Range Not Satisfiable";
      ReasonPhrases2["RESET_CONTENT"] = "Reset Content";
      ReasonPhrases2["SEE_OTHER"] = "See Other";
      ReasonPhrases2["SERVICE_UNAVAILABLE"] = "Service Unavailable";
      ReasonPhrases2["SWITCHING_PROTOCOLS"] = "Switching Protocols";
      ReasonPhrases2["TEMPORARY_REDIRECT"] = "Temporary Redirect";
      ReasonPhrases2["TOO_MANY_REQUESTS"] = "Too Many Requests";
      ReasonPhrases2["UNAUTHORIZED"] = "Unauthorized";
      ReasonPhrases2["UNAVAILABLE_FOR_LEGAL_REASONS"] = "Unavailable For Legal Reasons";
      ReasonPhrases2["UNPROCESSABLE_ENTITY"] = "Unprocessable Entity";
      ReasonPhrases2["UNSUPPORTED_MEDIA_TYPE"] = "Unsupported Media Type";
      ReasonPhrases2["USE_PROXY"] = "Use Proxy";
      ReasonPhrases2["MISDIRECTED_REQUEST"] = "Misdirected Request";
    })(ReasonPhrases = exports.ReasonPhrases || (exports.ReasonPhrases = {}));
  }
});

// node_modules/http-status-codes/build/cjs/index.js
var require_cjs = __commonJS({
  "node_modules/http-status-codes/build/cjs/index.js"(exports) {
    "use strict";
    var __assign = exports && exports.__assign || function() {
      __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s)
            if (Object.prototype.hasOwnProperty.call(s, p))
              t[p] = s[p];
        }
        return t;
      };
      return __assign.apply(this, arguments);
    };
    var __createBinding = exports && exports.__createBinding || (Object.create ? function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      Object.defineProperty(o, k2, { enumerable: true, get: function() {
        return m[k];
      } });
    } : function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      o[k2] = m[k];
    });
    var __exportStar = exports && exports.__exportStar || function(m, exports2) {
      for (var p in m)
        if (p !== "default" && !exports2.hasOwnProperty(p))
          __createBinding(exports2, m, p);
    };
    var __importDefault = exports && exports.__importDefault || function(mod) {
      return mod && mod.__esModule ? mod : { "default": mod };
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    var legacy_1 = __importDefault(require_legacy());
    var utils_functions_1 = require_utils_functions();
    var utils_functions_2 = require_utils_functions();
    Object.defineProperty(exports, "getStatusCode", { enumerable: true, get: function() {
      return utils_functions_2.getStatusCode;
    } });
    Object.defineProperty(exports, "getReasonPhrase", { enumerable: true, get: function() {
      return utils_functions_2.getReasonPhrase;
    } });
    Object.defineProperty(exports, "getStatusText", { enumerable: true, get: function() {
      return utils_functions_2.getStatusText;
    } });
    var status_codes_1 = require_status_codes();
    Object.defineProperty(exports, "StatusCodes", { enumerable: true, get: function() {
      return status_codes_1.StatusCodes;
    } });
    var reason_phrases_1 = require_reason_phrases();
    Object.defineProperty(exports, "ReasonPhrases", { enumerable: true, get: function() {
      return reason_phrases_1.ReasonPhrases;
    } });
    __exportStar(require_legacy(), exports);
    exports.default = __assign(__assign({}, legacy_1.default), {
      getStatusCode: utils_functions_1.getStatusCode,
      getStatusText: utils_functions_1.getStatusText
    });
  }
});

// netlify/functions/register/register.ts
var register_exports = {};
__export(register_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(register_exports);

// node_modules/get-file-exports/src/index.mjs
var import_esbuild = __toESM(require_main(), 1);
var import_node_eval = __toESM(require_node_eval(), 1);

// node_modules/astro-i18n/dist/src/index.mjs
var K = (t, n, r) => {
  if (!n.has(t))
    throw TypeError("Cannot " + r);
};
var y = (t, n, r) => (K(t, n, "read from private field"), r ? r.call(t) : n.get(t));
var I = (t, n, r) => {
  if (n.has(t))
    throw TypeError("Cannot add the same private member more than once");
  n instanceof WeakSet ? n.add(t) : n.set(t, r);
};
var P = (t, n, r, e) => (K(t, n, "write to private field"), e ? e.call(t, r) : n.set(t, r), r);
var at = (t, n, r) => (K(t, n, "access private method"), r);
function T(t) {
  return Object.getPrototypeOf(t) === Object.prototype;
}
function R(t) {
  return Object.entries(t);
}
function x(t, n, r) {
  let { mode: e, modifyBase: o } = __spreadValues({ mode: "replace", modifyBase: true }, r), i = o ? t : Y(t);
  for (let [s, a] of R(n)) {
    let f = i[s];
    if (lt(i, s)) {
      T(f) && T(a) ? x(f, a) : e === "replace" && (i[s] = n[s]);
      continue;
    }
    i[s] = n[s];
  }
  return i;
}
function Y(t) {
  return !t || typeof t != "object" ? t : Array.isArray(t) ? t.map((n) => typeof n == "object" ? Y(n) : n) : R(t).reduce((n, [r, e]) => {
    let o = n;
    return o[r] = Y(e), n;
  }, {});
}
function lt(t, n) {
  return Object.prototype.hasOwnProperty.call(t, n);
}
var vt = "astro-i18n";
var O = ".";
var zt = `.${vt}`;
var yt = ":";
var q = "|";
var xt = ",";
var ht = ":";
var Yt = { defaultLangCode: "en", supportedLangCodes: [], showDefaultLangCode: false, translations: {}, routeTranslations: {} };
function Q() {
  return __spreadValues({}, Yt);
}
function Bt(t) {
  return t;
}
function V(t, n) {
  let r = t.exec(n);
  if (!r)
    return null;
  let e = { range: [r.index, r.index + r[0].length], match: [...r] };
  return t.lastIndex = 0, e;
}
function Pt(t) {
  if (typeof t == "number")
    return t;
  if (typeof t == "string") {
    let n = Number.parseFloat(t);
    if (!Number.isNaN(n))
      return n;
  }
}
function Nt(t) {
  let n = typeof t == "string" || typeof t == "number" ? new Date(t) : t;
  if (n instanceof Date && !Number.isNaN(n.getTime()))
    return n;
}
function U(t, n) {
  var r;
  return (r = t.match(new RegExp(`^/?(${n.join("|")})(?:/.*)?$`))) == null ? void 0 : r[1];
}
function v({ defaultLangCode: t, routeTranslations: n }) {
  let r = { [t]: {} }, e = Object.entries(n).filter(([o]) => o !== t);
  for (let [o, i] of e) {
    r[o] = {};
    let s = e.filter(([a]) => a !== o);
    for (let [a, f] of Object.entries(i)) {
      r[t][a] || (r[t][a] = {}), r[t][a][o] = f, r[o][f] = { [t]: a };
      for (let [p, m] of s)
        m[a] && (r[o][f][p] = m[a]);
    }
  }
  return r;
}
var $;
var S;
var C;
var E;
var z;
var Lt;
var rt = class {
  constructor() {
    I(this, z);
    I(this, $, {});
    I(this, S, {});
    I(this, C, void 0);
    I(this, E, { number: (n2, r = {}, e = y(this, C)) => {
      if (typeof e != "string" || typeof r != "object" || !r)
        return String(n2);
      let o = Pt(n2);
      return o === void 0 ? String(n2) : new Intl.NumberFormat(e, r).format(o);
    }, date: (n2, r = {}, e = y(this, C)) => {
      if (typeof e != "string" || typeof r != "object" || !r)
        return String(n2);
      let o = Nt(n2);
      return o === void 0 ? String(n2) : new Intl.DateTimeFormat(e, r).format(o);
    } });
    let n = Q();
    this.defaultLangCode = n.defaultLangCode, this.supportedLangCodes = n.supportedLangCodes, this.showDefaultLangCode = n.showDefaultLangCode, this.translations = n.translations, this.routeTranslations = n.routeTranslations, P(this, C, this.defaultLangCode);
  }
  get langCodes() {
    return [this.defaultLangCode, ...this.supportedLangCodes];
  }
  get langCode() {
    return y(this, C);
  }
  set langCode(n) {
    if (!this.langCodes.includes(n))
      throw new Error(`Cannot set langCode to "${n}". "${n}" is not not supported, did you add it to the astro-i18n config file ?`);
    P(this, C, n);
  }
  get formatters() {
    return y(this, E);
  }
  internals() {
    return { init: at(this, z, Lt).bind(this), translationVariants: y(this, S), fullRouteTranslations: y(this, $) };
  }
  addTranslations(n) {
    let r = G(n);
    x(this.translations, n), x(y(this, S), r);
  }
  addRouteTranslations(n) {
    let r = v(__spreadProps(__spreadValues({}, this), { routeTranslations: n }));
    x(this.routeTranslations, n), x(y(this, $), r);
  }
  getFormatter(n) {
    return y(this, E)[n];
  }
  setFormatter(n, r) {
    y(this, E)[n] = r;
  }
  deleteFormatter(n) {
    delete y(this, E)[n];
  }
  init(n, r) {
    let e = U(n.url.pathname, this.langCodes);
    if (e && !this.langCodes.includes(e) && (e = this.defaultLangCode), this.langCode = e || this.defaultLangCode, r)
      for (let [o, i] of Object.entries(r))
        this.setFormatter(o, i);
  }
};
$ = /* @__PURE__ */ new WeakMap(), S = /* @__PURE__ */ new WeakMap(), C = /* @__PURE__ */ new WeakMap(), E = /* @__PURE__ */ new WeakMap(), z = /* @__PURE__ */ new WeakSet(), Lt = function(n, r = {}, e = {}) {
  for (let [o, i] of R(n))
    this[o] !== void 0 && (this[o] = i);
  P(this, $, e), P(this, S, r);
};
var mn = new rt();
var J = /{([\dA-Za-z]+:[^}]+)}/g;
var Tn = /{([\dA-Za-z]+)(:[^|}]+)?(|[^}]+)}/g;
var Ft = /[\dA-Za-z]+/;
var yn = /^["'].+["']$/;
var xn = /^-? ?\d+(.\d+)?$/;
function bt(t) {
  let n = hn(t);
  return n ? { name: t.replace(J, ""), variant: n } : { name: t, variant: { name: t, properties: [] } };
}
function hn(t) {
  let n = V(J, t);
  if (!n)
    return;
  let { match: r } = n;
  if (!r[1])
    return;
  let e = [];
  for (let o of r[1].split(xt)) {
    let [i, s] = o.split(ht).map((f) => f.trim());
    if (i === o || !Ft.test(i))
      continue;
    let a = ot(s);
    typeof a != "string" && typeof a != "number" || e.push({ name: i, value: a });
  }
  return { name: t, properties: e };
}
function et(t) {
  let n = [], r = t.matchAll(Tn);
  for (let e of r) {
    let o = Rn(e);
    o && n.push(o);
  }
  return n.sort((e, o) => o.range[1] - e.range[1]);
}
function Rn(t) {
  if (t.index === void 0)
    return;
  let n = { name: "", default: void 0, formatters: [], range: [t.index, t.index + t[0].length] };
  for (let r = 1; r < t.length; r += 1)
    !t[r] || (r === 1 && (n.name = t[r]), r === 2 && (n.default = An(t[r])), r === 3 && (n.formatters = Cn(t[r])));
  if (n.name)
    return n;
}
function An(t) {
  if (t[0] === yt)
    return ot(t.slice(1));
}
function Cn(t) {
  return t[0] !== q ? [] : t.split(q).filter((n) => !!n).map((n) => {
    if (!/[\dA-Za-z]+\(.+\)/.test(n))
      return { name: n, arguments: [] };
    let r = n.indexOf("(");
    return { name: n.slice(0, r), arguments: n.slice(r + 1, n.lastIndexOf(")")).split(",").map((o) => En(o.trim())) };
  });
}
function En(t) {
  let n = ot(t, false);
  return n && typeof n == "object" && Ft.test(t) ? { getter: (r) => r == null ? void 0 : r[n.name], name: n.name } : { getter: () => n };
}
function ot(t, n = true) {
  if (t === "null")
    return null;
  if (t === "undefined")
    return;
  if (t === "true")
    return true;
  if (t === "false")
    return false;
  let r = t.match(yn);
  if (r)
    return r[0].slice(1).slice(0, -1);
  if (r = t.match(xn), r)
    return Number.parseFloat(r[0].replace(" ", ""));
  if (n)
    throw new Error(`Could not parse "${t}" (not a primitive).`);
  return { name: t };
}
function G(t) {
  let n = {}, r = /* @__PURE__ */ new Set();
  return it(t, (e, { variant: o }) => {
    if (!o)
      return;
    let i = Dt(e, o);
    r.has(i) || (n[e] || (n[e] = []), n[e].push(o), r.add(i));
  }), n;
}
function Dt(t, n) {
  let r = t.lastIndexOf(O);
  return r < 0 ? n.name : `${t.slice(0, r)}${O}${n.name}`;
}
function it(t, n, r) {
  let { path: e, first: o } = __spreadValues({ path: "", first: true }, r);
  for (let [i, s] of R(t)) {
    let a = bt(i);
    if (typeof s == "string") {
      n(`${e}${a.name}`, a, et(s));
      continue;
    }
    if (o) {
      it(s, n, { path: "", first: false });
      continue;
    }
    it(s, n, { path: `${e}${a.name}${O}`, first: false });
  }
}

// astro.i18n.config.ts
var siteUrl = "https://lawellpietonne.com";
var fr = {
  siteUrlBase: siteUrl,
  siteUrl,
  siteName: "La Well pi\xE9tonne",
  siteDescription: "Consultation publique et p\xE9tition pour la pi\xE9tonnisation permanente de la rue Wellington",
  otherLangs: {
    en: "English"
  },
  headerDescription: "Une initiative pour pi\xE9tonniser la rue Wellington en permanence",
  step: "\xE9tape",
  completed: "compl\xE9t\xE9e",
  stepsTitle: "Progr\xE8s de l'initiative",
  steps: {
    1: {
      title: "Projet de p\xE9tition",
      subtitle: "Sign\xE9e par 25 r\xE9sidents"
    },
    2: {
      title: "Texte approuv\xE9",
      subtitle: "par l'arrondissement de Verdun"
    },
    3: {
      title: "P\xE9riode de signatures",
      subtitle: "90 jours - 3031 signatures"
    },
    4: {
      title: "Consultation publique",
      subtitle: "avec les r\xE9sidents de Verdun"
    }
  },
  petitionTextHeading: "La texte du p\xE9tition",
  seeCta: "Voir la p\xE9tition",
  signCta: "Signer la p\xE9tition",
  signCtaSubtext: "sur montreal.ca",
  signCtaRequirements: "R\xE9sidents de Verdun \xE2g\xE9 de 15 ans ou plus",
  email: "Courriel",
  optional: "facultatif",
  inspirationAndReading: "Inspiration et lecture",
  footerNoticeUnaffiliated: "Ce site n'est pas affili\xE9e \xE0 ",
  contactUs: "Contactez-nous",
  notFound: "404 : Introuvable",
  goHome: "Page d'accueil",
  petitionUrl: "https://montreal.ca/petitions/detail/6428dc4ac490e6ee4229c32a",
  petitionSignUrl: "https://montreal.ca/petitions/signer/6428dc4ac490e6ee4229c32a"
};
var en = {
  siteUrlBase: siteUrl,
  siteUrl: `${siteUrl}/en`,
  siteName: "La Well Pi\xE9tonne",
  siteDescription: "A public consultation and petition to pedestrianize Wellington street permanently",
  otherLangs: {
    fr: "Fran\xE7ais"
  },
  headerDescription: "An initiative to make Wellington a pedestrian street permanently",
  step: "step",
  completed: "completed",
  stepsTitle: "Initiative progress",
  steps: {
    1: {
      title: "Petition draft",
      subtitle: "Signed by 25 residents"
    },
    2: {
      title: "Petition text approved",
      subtitle: "by the borough of Verdun"
    },
    3: {
      title: "Signature period",
      subtitle: "90 days - 3031 signatures"
    },
    4: {
      title: "Public consultation",
      subtitle: "with residents of Verdun"
    }
  },
  petitionTextHeading: "Petition text",
  seeCta: "See the petition",
  signCta: "Sign the petition",
  signCtaSubtext: "on montreal.ca",
  signCtaRequirements: "Must be a resident of Verdun age 15 or older",
  email: "E-mail",
  optional: "optional",
  inspirationAndReading: "Inspiration and reading",
  footerNoticeUnaffiliated: "This site is not affiliated with ",
  contactUs: "Contact us",
  notFound: "404: Not Found",
  goHome: "Go home",
  petitionUrl: "https://montreal.ca/en/petitions/details/6428dc4ac490e6ee4229c32a",
  petitionSignUrl: "https://montreal.ca/en/petitions/sign/6428dc4ac490e6ee4229c32a"
};
var translations = { en, fr };
var astro_i18n_config_default = Bt({
  defaultLangCode: "fr",
  supportedLangCodes: ["en"],
  showDefaultLangCode: false,
  translations: { en, fr },
  routeTranslations: {
    en: {
      signer: "sign",
      petition: "petition"
    }
  }
});

// netlify/functions/register/register.ts
var import_http_status_codes = __toESM(require_cjs());
var handler = async ({ body }) => {
  var _a, _b;
  try {
    const { email, lang = "fr" } = JSON.parse(body);
    const montrealRegistration = "https://api.montreal.ca/api/it-platforms/security/v1/tickets/registration";
    const data = {
      email,
      language: lang,
      redirectUri: translations[lang].petitionUrl
    };
    const response = await fetch(montrealRegistration, {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(data)
    });
    const responseJson = await response.json();
    const invalidEmailError = ((_a = responseJson.error) == null ? void 0 : _a.code) === "invalidParameter";
    if (invalidEmailError) {
      return {
        statusCode: import_http_status_codes.StatusCodes.BAD_REQUEST
      };
    }
    const hasMontrealAccount = ((_b = responseJson.error) == null ? void 0 : _b.code) === "accountAlreadyExists";
    if (hasMontrealAccount) {
      return {
        statusCode: import_http_status_codes.StatusCodes.OK
      };
    }
    const accountCreated = responseJson.email;
    if (accountCreated) {
      return {
        statusCode: import_http_status_codes.StatusCodes.CREATED
      };
    }
    throw new Error(JSON.stringify(responseJson));
  } catch (error) {
    return {
      statusCode: import_http_status_codes.StatusCodes.INTERNAL_SERVER_ERROR,
      body: JSON.stringify({
        error
      })
    };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
